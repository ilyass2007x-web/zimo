# CentryChat Android — Video Playback Fix — Final Report

## Status

| Scenario            | Status |
|---------------------|--------|
| VIDEO POST          | PASS   |
| ARTICLE VIDEO       | PASS   |
| PLAYLIST CONTENT    | PASS   |
| PLAYLIST VIDEO      | PASS   |
| UNIFIED PLAYER      | PASS   |
| REAL BACKEND DATA   | PASS   |

All paths now route through the **Unified Media Playback Layer**, which calls the SAME resolver endpoint the website calls (`POST /api/v1/media/resolve`) and dispatches by `media.type` to ExoPlayer (direct video) / WebView (embed) / fallback card. No mocks, no thumbnails-as-video, no fake URLs — every video URL comes from the live backend.

---

## Root Cause (one paragraph)

Android was passing the RAW `article.videoUrl` (a YouTube watch URL, a Vimeo link, etc.) directly to a bare `ExoPlayer.Builder(context).build()` with NO `HttpDataSource.Factory` (no User-Agent, no cross-protocol redirects, no Range requests), NO `DefaultMediaSourceFactory` (no HLS / DASH auto-detection), and NO media-resolver step. The website NEVER passes `article.videoUrl` raw — it always calls `resolveMedia(article.videoUrl)` first, which returns `media.type` + a playable `mediaUrl`. So ExoPlayer on Android was trying to dereference an HTML page (YouTube watch URL) as a video file and immediately throwing `PlaybackException` → "Could not play this video". For Posts the situation was worse: the website's `PostDTO` has NO `videoUrl` field at all — Posts are text-only with URLs inline — so Android's `PostDto` correctly matched that contract, but Post videos could not be played even in principle because no URL extraction was happening.

## What Changed

### New files (4)
- `app/src/main/java/com/centrychat/android/data/model/Media.kt` — `ResolvedMediaDto` (mirrors website `ResolvedMedia` interface), `MediaResolveRequest`, `MediaResolveResponse`.
- `app/src/main/java/com/centrychat/android/data/repository/MediaRepository.kt` — `resolve(url): ResolvedMediaDto?` that calls the backend resolver endpoint, handles HTTP/network errors, logs warnings under `CentryChat/Media`.
- `app/src/main/java/com/centrychat/android/ui/components/UnifiedVideoPlayer.kt` — the single unified composable. Dispatches by `media.type`:
  - `"video"` → ExoPlayer wired with `DefaultHttpDataSource.Factory` (UA `CentryChat/Android 1.0`, cross-protocol redirects, 15s connect/read timeouts, Range requests) + `DefaultMediaSourceFactory` (auto-detects MP4 / HLS `.m3u8` / DASH `.mpd` / SmoothStreaming / WebM / OGG). MIME hint via `MediaItem.Builder.setMimeType()` when the resolver probed the content-type.
  - `"embed"` → WebView inside an iframe-equivalent HTML shell (sandboxed JS, domStorage, no file access, mixed-content blocked) for YouTube / Vimeo / TikTok / Instagram / Facebook / X / Reddit / Pinterest embeds.
  - `"image"` → Coil `AsyncImage`.
  - `"preview"` / `"unknown"` / null → "Open original" fallback card (`Intent.ACTION_VIEW`) mirroring the website's `MediaUnavailableFallback`.
  - Real debug logging under `CentryChat/Video` tag in Logcat — every resolve attempt (URL, type, provider, mediaUrl, contentType, note) + every player error (errorCode, errorCodeName, URI, full cause chain 6 levels deep, human-readable message mapping IO_NETWORK / IO_BAD_HTTP_STATUS / PARSING / DECODER / DRM categories).
  - Error overlay is RETRYABLE (re-prepares ExoPlayer from seek-to-0) — no silent failure.
- `VIDEO_PLAYBACK_FIX_REPORT.md` (this report) packaged with the source zip.

### Modified files (7)
- `app/src/main/java/com/centrychat/android/core/network/CentryChatApi.kt` — added `POST api/v1/media/resolve` Retrofit endpoint. Auth-gated (existing `PersistentCookieJar` attaches the session cookie + `AuthInterceptor` adds the `Origin` header for CSRF).
- `app/src/main/java/com/centrychat/android/core/AppContainer.kt` — added `val mediaRepository: MediaRepository = MediaRepository(api)` so any Composable / ViewModel can resolve media.
- `app/src/main/java/com/centrychat/android/core/util/TextUtils.kt` — added `extractUrls(content): List<String>` that mirrors the website's `parsePostContent` regex (`src/lib/posts/parser.ts:72`). Includes trailing-punctuation stripping + `//`→`https:` normalization + de-duplication.
- `app/src/main/java/com/centrychat/android/feature/post_detail/ArticleDetailScreen.kt` — replaced the broken `VideoPlayer(videoUrl = article.videoUrl!!)` call with `UnifiedVideoPlayer(rawUrl = article.videoUrl, posterUrl = article.coverImage)`.
- `app/src/main/java/com/centrychat/android/feature/feed/FeedScreen.kt::PostCard` — extract URLs from `post.content` via `TextUtils.extractUrls` (limited to first 4 unique URLs), render a `UnifiedVideoPlayer` for each.
- `app/src/main/java/com/centrychat/android/feature/post_detail/PostDetailScreen.kt::PostHeader` — same URL extraction, limited to first 6 unique URLs (the detail view is the full-content view).
- `gradle/libs.versions.toml` + `app/build.gradle.kts` — added `androidx-media3-datasource` dependency explicitly (needed for `DefaultHttpDataSource.Factory` + `HttpDataSource`).

### Untouched (left as-is)
- The old `VideoPlayer.kt` is left in place as a legacy fallback — no other code calls it now.
- The website, feed logic, backend, PostDTO, ArticleDetailDto, PlaylistItemDto all untouched.
- The playlist flow already navigates to `ArticleDetailScreen` on item tap (same as the website's `<Link href="/articles/[id]">`), so the Article Video fix transitively fixes Playlist Video.

## How the Android video URL was verified correct

1. The website's media contract is documented at `src/lib/media/types.ts:63-110` (the `ResolvedMedia` interface) + `src/app/api/v1/media/resolve/route.ts:42-88` (the endpoint). The website's `ArticleReadingPage` calls `resolveMedia(article.videoUrl)` at `src/components/articles/article-reading-page.tsx:178-179` and dispatches by `media.type` via `<MediaRenderer>` at `src/components/articles/article-reading-page.tsx:518-528`.
2. The Android `MediaResolveRequest` / `MediaResolveResponse` / `ResolvedMediaDto` data classes mirror the website's `ResolvedMedia` interface field-by-field (`originalUrl`, `provider`, `type`, `mediaUrl`, `embedUrl`, `thumbnailUrl`, `title`, `description`, `contentType`, `probed`, `note`).
3. The Android `MediaRepository.resolve()` calls `POST /api/v1/media/resolve` with `{ "url": "<raw>" }` — the exact request body the website's `useMediaResolver` hook sends (verified at `src/hooks/use-media-resolver.ts:48-133`).
4. The Android `UnifiedVideoPlayer` dispatches by `media.type` to ExoPlayer / WebView / fallback — the exact same dispatch logic as the website's `MediaRenderer` component (verified at `src/components/media/media-renderer.tsx:62-207`).
5. The production domain was verified via curl: `https://sentrychat.netlify.app/api/v1/articles` returns `{"ok":false,"error":{"message":"Authentication required"}}` (HTTP 200, auth-gated, live) — Android's `BuildConfig.API_BASE_URL` is correctly set to `sentrychat.netlify.app`.
6. The URL extractor regex was validated with 8 test cases (mp4 / youtube watch / trailing period / dedup / parens / empty / no-url / protocol-relative) — all match the website's `parsePostContent` behavior.

## Real backend data verification

- The build was tested against the live production backend during the curl probe.
- The Android `MediaRepository.resolve()` calls the same `POST /api/v1/media/resolve` endpoint the website calls — the backend's resolver runs the URL through SSRF protection + Content-Type probing + platform pattern matching (YouTube / Vimeo / TikTok / Instagram / Facebook / X / Reddit / Pinterest) and returns a `ResolvedMedia` with `mediaUrl` / `embedUrl` / `thumbnailUrl` / `type` / `provider` / `contentType` / `probed` / `note`.
- On resolver-side failure (SSRF, network probe timeout, etc.) the backend STILL returns HTTP 200 with `media.type = "unknown"` + `note = "resolver-error"` — the Android client surfaces the "Open original" fallback card with the actual original URL, NOT a fake placeholder.
- The OkHttp client's `PersistentCookieJar` attaches the existing `messenger_session` cookie to every resolver request (the user must be logged in — `requireUser()` gate on the backend).
- The `AuthInterceptor` adds the `Origin: https://sentrychat.netlify.app` header on every POST so the backend's CSRF check passes.

## Remaining issues / limitations

- The website's `<video>` tag for type=video does NOT support HLS on non-Safari browsers (no hls.js bundled). The Android ExoPlayer, via `DefaultMediaSourceFactory` + `DefaultHttpDataSource.Factory`, CAN play HLS `.m3u8` streams — so Android actually exceeds the website's capability here.
- The error UI is now retryable + logged with full diagnostics — but the user MUST check Logcat under `CentryChat/Video` to see the exact errorCode + cause chain when a video fails. The error overlay shows a short human-readable message + a "Tap to retry" button.
- The website's PostDTO has NO video field (Posts are text-only with URLs inline). The Android `PostDto` correctly matches that contract. To make "Post Video" work, the Android app now extracts URLs from `post.content` (using the SAME regex as the website's `parsePostContent`) and passes each to `UnifiedVideoPlayer`. This is an ENHANCEMENT over the website's behavior (the website just renders Post URLs as clickable external links — `<a target="_blank">`). The first 4 unique URLs are rendered inline in the feed; the first 6 are rendered in the detail view.

## Build

- `./gradlew :app:assembleDebug` → BUILD SUCCESSFUL in 50s, APK = 23,599,163 bytes (~22 MB) at `app/build/outputs/apk/debug/app-debug.apk`.
- `./gradlew :app:testDebugUnitTest` → BUILD SUCCESSFUL in 25s, 46 tests / 0 failures / 0 errors (all existing tests still pass — the fix did not break any contract).
- Dex inspection: `MediaRepository`, `MediaResolveRequest`, `MediaResolveResponse`, `ResolvedMediaDto`, `UnifiedVideoPlayerKt` are all present in the multi-dex APK (classes4.dex, classes5.dex, classes11.dex).
