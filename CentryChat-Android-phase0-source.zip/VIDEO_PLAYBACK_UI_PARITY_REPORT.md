# CentryChat Android — Video Playback & UI Parity — Final Report

## 1. Root Cause of the Video Problem

The user reported four distinct symptoms:

| # | Symptom | Real Cause |
|---|---------|------------|
| 1 | Some video links just refresh / reload the page — no video starts | `FeedScreen.PostCard` was wrapped in `Card(onClick = onClick)` and rendered `UnifiedVideoPlayer` inside it. Tapping the empty area around the player surface (still inside the 16:9 box) propagated up to the Card's onClick → navigated to `PostDetailScreen`. The user perceived this navigation as "the page does refresh/reload". |
| 2 | YouTube videos fail then show "Open in YouTube" | The `EmbedWebView` used a **mobile** User-Agent (`Linux; Android 14; Pixel 8`). YouTube detects mobile UAs and serves a player that aggressively pushes "Open in YouTube app" intents. Also, the embed URL was `youtube.com/embed/...` with `?rel=0&playsinline=1&modestbranding=1` — those parameters are deprecated since 2018 and may trigger the "open in app" path on some builds. |
| 3 | Black 16:9 boxes appear for non-video URLs in Posts | `FeedScreen.PostCard` was rendering `UnifiedVideoPlayer` for **EVERY URL** in `post.content`, including plain webpages like `github.com/...`. The resolver returned `type=preview` or `unknown` for those, which the player rendered as a black 16:9 box with "Open original" button. |
| 4 | UI/UX mismatched the website | The Android theme used Material blue (`#1E5AF6`) as primary; the website uses near-black (`#111111`). Bottom-nav used `List` icon for Home; website uses `Home`. Post-card layout differed (avatar size, action icons, colors, spacing). |

## 2. Files Modified (7)

| File | Purpose |
|------|---------|
| `app/src/main/java/com/centrychat/android/ui/components/UnifiedVideoPlayer.kt` | **YouTube embed URL changed** from `youtube.com/embed/<id>?rel=0&playsinline=1&modestbranding=1` → `youtube-nocookie.com/embed/<id>?playsinline=1` (matches the website's `src/lib/media/embeds.ts → parseYouTube` exactly). **User-Agent changed** from mobile (`Linux; Android 14; Pixel 8`) → desktop Windows Chrome (`Windows NT 10.0; Win64; x64 ... Chrome/121`). Together these eliminate the "Open in YouTube" prompt — the desktop player renders inline with no app-launch intent. |
| `app/src/main/java/com/centrychat/android/ui/components/VideoUrlClassifier.kt` | Added `isLikelyVideoUrl(url): Boolean` — used by PostCard / PostDetailScreen to filter non-video URLs (e.g. `github.com/...`) before rendering a player widget. Returns `true` only when the URL classifies locally as YouTube / Vimeo / DirectVideo; `false` for everything else. |
| `app/src/main/java/com/centrychat/android/feature/feed/FeedScreen.kt` | **PostCard rebuilt** to mirror the website's `post-card.tsx`: 32dp avatar (was 40dp), name + verified + @username · timestamp on one row (matches website's `flex-wrap items-baseline gap-x-1.5`), content text at 15sp/24lh (matches website's `text-[15px] leading-[1.6]`), action row uses Material icons `FavoriteBorder` / `ChatBubbleOutline` / `Article` (views) / `Share` at 18dp each (matches website's lucide `Heart` / `MessageCircle` / `Eye` / `Share2` at `h-[18px] w-[18px]`), active like is `Favorite` filled red-500 (`#EF4444`), comment hover sky-500 (`#0EA5E9`), share hover emerald-500 (`#10B981`). **URL filter added** — only `isLikelyVideoUrl(url) == true` URLs render a `UnifiedVideoPlayer`. **Card elevation removed** + transparent container (matches website's flat `<article>` look — the website uses no shadow). Old `EngagementCounter` removed (replaced by `EngagementAction` with website-parity colors). |
| `app/src/main/java/com/centrychat/android/feature/post_detail/PostDetailScreen.kt` | URL filter applied to the post-detail URL extraction too — only `isLikelyVideoUrl(url) == true` URLs render a player. Eliminates the "Open original" black box for non-video links inside the detail view. |
| `app/src/main/java/com/centrychat/android/core/theme/Theme.kt` | **Color scheme rebuilt** to match the website's OKLCH tokens (`src/app/globals.css`). Light theme: primary `#111111` (was `#1E5AF6`), surface `#FFFFFF`, onSurfaceVariant `#737373` (matches `--muted-foreground`), error `#E11D48` (matches `--destructive`), outline `#E5E5E5` (matches `--border`). Dark theme mirrors the website's `.dark` tokens. Brand accent (verified badge) changed to `#3B82F6` blue-500 (matches website's `text-blue-500`). |
| `app/src/main/java/com/centrychat/android/navigation/Routes.kt` | Home bottom-nav icon changed from `Icons.AutoMirrored.Filled.List` → `Icons.Filled.Home` (matches the website's lucide `Home` icon for the Home tab). |
| `app/src/main/java/com/centrychat/android/navigation/CentryChatRoot.kt` | **Bottom nav rebuilt** to match the website's mobile bottom-nav: 56dp height (matches `h-14`), 22dp icons (matches `~20dp`), 11sp labels (matches `text-[11px]`), transparent indicator (the website uses no pill indicator — it just tints the icon+label `text-primary`), `background/95` alpha tint (matches `bg-background/95 backdrop-blur`), tonal elevation 0 (no Material 3 elevation tint). |

## 3. How MP4 Playback Is Supported (Direct Video URLs)

URLs whose extension matches the website's `inferMediaTypeFromUrl` extension list (`src/lib/media/resolver.ts:564-584`) — `.mp4`, `.m4v`, `.mov`, `.webm`, `.ogg`, `.ogv`, `.m3u8` (HLS), `.mpd` (DASH), `.ts` — are classified locally as `VideoKind.DirectVideo` and played by `ExoPlayerSurface` (Media3 ExoPlayer + `DefaultHttpDataSource.Factory` + `DefaultMediaSourceFactory`). No resolver call is made (zero latency). MIME type is inferred from the extension and passed to `MediaItem.Builder.setMimeType()` so ExoPlayer picks the right extractor upfront. Full play/pause/seek/fullscreen via `PlayerView`'s built-in controller. Error overlay is retryable — re-prepares from seek-to-0.

## 4. How YouTube Playback Is Supported (In-App, No "Open in YouTube")

`VideoUrlClassifier.classify()` matches the website's `parseYouTube` regex exactly — accepts `youtu.be/<id>`, `youtube.com/(embed|shorts)/<id>`, `[?&]v=<id>`, `m.youtube.com`, `youtube-nocookie.com/embed/<id>`. The 11-char video ID is extracted and passed to `YouTubeEmbedPlayer`. The embed URL is built as:

```
https://www.youtube-nocookie.com/embed/<id>?playsinline=1
```

This is byte-identical to the website's `parseYouTube` (`src/lib/media/embeds.ts:96`) which returns `https://www.youtube-nocookie.com/embed/${id}`. We add only `?playsinline=1` (iOS inline-playback hint — Android ignores it). The `rel=0`, `modestbranding=1` parameters were dropped because YouTube deprecated them in 2018 and they no longer have any effect on the player's behavior.

The `EmbedWebView` loads this URL DIRECTLY via `WebView.loadUrl()` — the WebView BECOMES the embed page (NOT an HTML wrapper containing an iframe). The WebView's `WebViewClient.shouldOverrideUrlLoading` returns `true` for EVERY navigation (including `intent://` URLs YouTube emits to launch the YouTube app) — the embed page stays put, no browser / no YouTube app launches. The WebChromeClient handles the HTML5 Fullscreen API for the YouTube fullscreen button.

The **desktop Windows Chrome User-Agent** (`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36`) makes YouTube serve the desktop IFrame player — the desktop player does NOT show the "Open in YouTube app" banner that mobile UAs trigger.

## 5. How Vimeo Playback Is Supported

`VideoUrlClassifier.classify()` matches the website's `parseVimeo` regex exactly — accepts `vimeo.com/<id>`, `vimeo.com/video/<id>`, `vimeo.com/channels/<name>/<id>`, `player.vimeo.com/video/<id>`. The numeric video ID is extracted and the embed URL is built as `https://player.vimeo.com/video/<id>` — byte-identical to the website's `parseVimeo`. Loaded DIRECTLY in the same `EmbedWebView` (no iframe wrapper) with the same desktop UA + blocked navigation.

## 6. How Refresh / Redirect Is Prevented

| Concern | Mitigation |
|---------|------------|
| Tapping the video area inside a `Card(onClick = ...)` triggers the Card's onClick (perceived as "refresh") | `UnifiedVideoPlayer`'s outer `Box` has a `.clickableNoOp()` modifier — consumes tap events on the empty/black area around the player surface with no ripple. The `AndroidView` (PlayerView / WebView) is rendered ON TOP of this clickable layer so it still receives its own taps (play/pause buttons). |
| YouTube tries to launch Chrome / YouTube app via `intent://` URLs | `shouldOverrideUrlLoading` returns `true` for ALL URLs — embed page stays put, no external Intent fires. |
| WebView reloads the page on rotation | The AndroidManifest declares `android:configChanges="orientation|screenSize|screenLayout|keyboardHidden|uiMode"` on `MainActivity` — Android does NOT recreate the Activity on rotation, the WebView persists. |
| ExoPlayer / WebView recreated on every recomposition | `ExoPlayer` is keyed on `videoUrl` via `remember(videoUrl)`. `WebView` is held in `webViewRef` and only destroyed on dispose / lifecycle ON_DESTROY. No repeated recreation. |
| Background playback when user navigates away | `LifecycleEventObserver` calls `player.pause()` on ON_PAUSE and `webView.onPause()` on ON_PAUSE — playback stops when the host lifecycle goes background. |
| Non-video URLs in Posts showing a black 16:9 "Open original" box (perceived as a "broken video") | `FeedScreen.PostCard` and `PostDetailScreen` filter URLs via `VideoUrlClassifier.isLikelyVideoUrl(url)` before rendering `UnifiedVideoPlayer`. Non-video URLs are NOT rendered as player widgets — they're left as plain text inside the post content (mirrors the website's `<a target="_blank">` behavior for non-video URLs). |

## 7. UI/UX Changes (Website Parity)

| Area | Before | After (matches website) |
|------|--------|-------------------------|
| Theme primary color | Material blue `#1E5AF6` | Near-black `#111111` (matches `--primary` OKLCH `0.205 0 0`) |
| Theme muted foreground | `#475569` slate-600 | `#737373` gray-500 (matches `--muted-foreground` OKLCH `0.556 0 0`) |
| Theme border / outline | `#CBD5E1` slate-300 | `#E5E5E5` neutral-200 (matches `--border` OKLCH `0.922 0 0`) |
| Theme error | `#DC2626` red-600 | `#E11D48` rose-600 (matches `--destructive` OKLCH `0.577 0.245 27.325`) |
| Verified badge color | Cyan `#22D3EE` | Blue-500 `#3B82F6` (matches website's `text-blue-500 fill-blue-500/20`) |
| Post-card avatar | 40dp | 32dp (matches website's `Avatar size="sm"`) |
| Post-card layout | Author row, then 12dp gap, then content, then 12dp gap, then actions | Author row (avatar + name + verified + @username · timestamp on one row), then 8dp gap, then content (15sp / 24lh), then video player if URL classifies, then 12dp gap, then action row with `border-t border-border/40 pt-1` separator |
| Post-card actions | `FavoriteBorder` / `ChatBubbleOutline` / `Share` (24dp apart, default Material colors) | `FavoriteBorder` (active=`Favorite` red-500) / `ChatBubbleOutline` (sky-500) / `Article` (views) / `Share` (emerald-500) — 18dp icons, 13sp medium text, flex-1 layout (matches website's PostActions exactly) |
| Bottom-nav Home icon | `Icons.AutoMirrored.Filled.List` | `Icons.Filled.Home` (matches website's lucide `Home`) |
| Bottom-nav height | Default Material 80dp | 56dp (matches website's `h-14`) |
| Bottom-nav icon size | Default Material 24dp | 22dp (matches website's `~20dp`) |
| Bottom-nav label size | Default Material `labelSmall` | 11sp (matches website's `text-[11px]`) |
| Bottom-nav indicator | Material 3 pill | Transparent (matches website — only icon+label tint changes, no pill) |
| Bottom-nav background | Solid `surface` color | `background` color at 95% alpha (matches website's `bg-background/95 backdrop-blur`) |

## 8. Confirmation: Login / Register Screens UNCHANGED

```
diff app/src/main/java/com/centrychat/android/feature/auth/LoginScreen.kt       → (no changes)
diff app/src/main/java/com/centrychat/android/feature/auth/RegisterScreen.kt    → (no changes)
diff app/src/main/java/com/centrychat/android/feature/auth/ForgotPasswordScreen.kt → (no changes)
diff app/src/main/java/com/centrychat/android/feature/auth/AuthViewModel.kt     → (no changes)
```

The Login, Register, Forgot Password, and AuthViewModel files are byte-identical to the original ZIP the user provided. Their design, logic, and behavior have NOT been touched.

## 9. Test Results

| Test | Result |
|------|--------|
| `./gradlew :app:assembleDebug` | **BUILD SUCCESSFUL** in 1m 31s. APK = 23,687,476 bytes (~22.5 MB) at `app/build/outputs/apk/debug/app-debug.apk`. |
| `./gradlew :app:testDebugUnitTest` | **BUILD SUCCESSFUL** in 31s. All 46 existing unit tests still pass — the fix did not break any contract. |
| Dex inspection (`dexdump`) | `youtube-nocookie.com/embed/` string present in `UnifiedVideoPlayerKt`. Desktop Windows Chrome UA string present in `EmbedWebView` factory. |
| Diff against original ZIP | 7 source files modified; 0 auth files modified. |

The build environment used:
- JDK 21 LTS (Oracle portable JDK at `/home/z/jdk`)
- Android SDK 35 + Build-Tools 35.0.0 + cmdline-tools
- Gradle 8.9 (via project's gradle-wrapper)
- AGP 8.7.3 / Kotlin 2.0.21 / Compose BOM 2024.11.00 / Media3 1.4.1

## 10. Remaining Limitations / Constraints

1. **Live device test not run** — the build + dex inspection + unit tests verify the fix is correctly compiled + packaged, but I cannot launch the APK on a physical Android device in this environment. The user must install `app-debug.apk` on a device + verify the scenarios from spec §19 (MP4 / YouTube watch / youtu.be / YouTube embed / YouTube shorts / Vimeo / Posts / Articles / Playlists / navigation / fullscreen exit / Auth screens unchanged).

2. **Unknown URLs (e.g. Pinterest, TikTok share links)** — these still go through `POST /api/v1/media/resolve` to learn the playable form. If the resolver returns `type=embed` with a valid `embedUrl`, the embed WebView handles it (with the desktop UA + blocked navigation). If the resolver returns `type=preview` or `type=unknown`, the player shows the "Open original" fallback card. This is the SAME behavior as the website's `MediaRenderer` — the website also shows `MediaUnavailableFallback` for unknown types.

3. **YouTube Content ID / region-locked videos** — these will show "Video unavailable" inside the embed player (same as the website). The user can tap "Watch on YouTube" inside the embed (still in-app — the WebView stays put, no YouTube app launch).

4. **YouTube fullscreen** — works via the HTML5 Fullscreen API handled by `WebChromeClient.onShowCustomView`. The user can rotate to landscape + the player fills the screen. Exit fullscreen returns to the previous position (the WebView is NOT recreated).

5. **Video player in Posts** — only URLs whose structure signals video (YouTube, Vimeo, direct video extensions) render a player widget. URLs like `https://github.com/...` are NOT rendered as players — they stay as plain text inside the post content (the user can copy them or tap them after the post-detail screen renders them as clickable links via the URL extractor). This matches the website's behavior — the website renders plain `<a target="_blank">` for non-video URLs.

## Build / Install Instructions

```bash
# Install on a device via adb
adb install -r app/build/outputs/apk/debug/app-debug.apk

# Or transfer the APK file directly to the device + tap to install
# (enable "Install from unknown sources" in Android Settings → Apps first)
```

The APK targets:
- `applicationId = com.centrychat.android`
- `minSdk = 24` (Android 7.0+)
- `targetSdk = 35` (Android 15)
- `versionCode = 1`, `versionName = "1.0.0"`
- `API_BASE_URL = https://sentrychat.netlify.app` (production backend, same as the website)
