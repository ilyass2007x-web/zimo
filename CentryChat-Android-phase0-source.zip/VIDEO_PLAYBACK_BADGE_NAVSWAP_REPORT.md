# CentryChat Android — Round 2 Final Report

## Summary

This round delivered four targeted changes on top of the Round 1 video-fix baseline:

1. **Verified badge unified + matched to website** — single shared `VerifiedBadge` component using Material's `Icons.Filled.Verified` (the Android-equivalent of lucide-react's `BadgeCheck`), in brand blue `#3B82F6` with semi-transparent fill, exactly matching the website's `text-blue-500 fill-blue-500/20`. Applied everywhere a username appears (including the previously-missing Notifications + Playlist Detail article author).
2. **Profile / Messages bottom-nav swap** — only the enum order in `Routes.kt` changed. Routes, icons, labels, click handlers, and navigation logic are untouched.
3. **Verified badge added to Notifications** — the sender's `isVerified` flag (returned by the backend's `NotificationSenderDto`) now drives a blue badge next to the sender's name.
4. **Verified badge added to Playlist Detail article author** — the article's `AuthorDto.isVerified` now drives a badge next to the `@username`.

## 1. Video (recap from Round 1 — verified still in place)

### Root cause
1. Tapping the empty area around a player inside a `Card(onClick=…)` propagated to the Card's onClick → user perceived "refresh / reload".
2. YouTube embed WebView used a mobile UA + `youtube.com/embed/…?rel=0&playsinline=1&modestbranding=1`. YouTube detected the mobile UA and aggressively pushed "Open in YouTube app".
3. Every URL in `post.content` (even non-video ones like `github.com/...`) rendered a `UnifiedVideoPlayer` widget — the resolver returned `type=preview` / `type=unknown` → the player showed a black 16:9 box with "Open original" button — user perceived as "broken video".

### What was fixed (Round 1, verified still in place this round)
- `UnifiedVideoPlayer.kt` — YouTube embed URL changed to `https://www.youtube-nocookie.com/embed/<id>?playsinline=1` (matches website's `src/lib/media/embeds.ts → parseYouTube` byte-for-byte). User-Agent changed to desktop Windows Chrome (`Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 … Chrome/121`). Together these eliminate the "Open in YouTube" prompt — YouTube serves the desktop IFrame player that plays inline.
- `VideoUrlClassifier.kt` — added `isLikelyVideoUrl(url): Boolean` — only `true` for YouTube / Vimeo / direct video URLs. Used by PostCard / PostDetailScreen to filter non-video URLs before rendering a player widget.
- `FeedScreen.kt::PostCard` — outer `Box` has `.clickableNoOp()` to consume parent Card taps. URL list filtered via `isLikelyVideoUrl`. `WebViewClient.shouldOverrideUrlLoading` returns `true` for ALL URLs (including `intent://` URLs that YouTube emits to launch the YouTube app) — embed page stays put, no browser / no YouTube app launches.
- `ExoPlayerSurface` unchanged — MP4 / HLS (.m3u8) / DASH (.mpd) / WebM / OGG all played by Media3 ExoPlayer + `DefaultHttpDataSource.Factory` + `DefaultMediaSourceFactory`.

### Supported video types (verified via dexdump — strings present in the APK)
| Type | URL pattern | Player | In-app? |
|------|-------------|--------|---------|
| Direct MP4 / HLS / DASH / WebM / OGG | `.mp4`, `.m3u8`, `.mpd`, etc. | Media3 ExoPlayer | ✓ |
| YouTube | `youtube.com/watch?v=…`, `youtu.be/…`, `youtube.com/embed/…`, `youtube.com/shorts/…`, `youtube-nocookie.com/embed/…` | WebView embed (`youtube-nocookie.com/embed/<id>`) | ✓ |
| Vimeo | `vimeo.com/<id>`, `vimeo.com/video/<id>`, `vimeo.com/channels/<name>/<id>`, `player.vimeo.com/video/<id>` | WebView embed (`player.vimeo.com/video/<id>`) | ✓ |

### Test verification
- `assembleDebug` BUILD SUCCESSFUL — APK 23.6 MB at `app/build/outputs/apk/debug/app-debug.apk`
- `testDebugUnitTest` BUILD SUCCESSFUL — 46 tests, 0 failures
- `dexdump` confirmed the strings `https://www.youtube-nocookie.com/embed/`, `Mozilla/5.0 (Windows NT 10.0; Win64; x64)`, and `isLikelyVideoUrl` are all present in the multi-dex APK.

### Remaining limitations
- Live on-device test was not run in this environment. The user must install `CentryChat-Android-1.0.0-debug.apk` on a real device and exercise the scenarios in spec §19 (MP4 / YouTube watch / youtu.be / YouTube embed / YouTube shorts / Vimeo / Posts / Articles / Playlists / navigation / fullscreen exit / Auth screens unchanged).
- YouTube Content ID / region-locked videos will show "Video unavailable" inside the embed (same as the website).
- Unknown URLs (Pinterest, TikTok share links) still go through the backend resolver — if the resolver returns `type=embed`, the WebView handles it; if it returns `type=preview` / `unknown`, the player shows the "Open original" fallback card (matches the website's `MediaUnavailableFallback` behavior).

## 2. Verification Badge — unified + applied everywhere

### Where the badge is rendered (after this round)

| Screen | Position | Source of `isVerified` |
|--------|----------|--------------------------|
| **Feed PostCard** | next to author fullName | `PostDto.author.isVerified` (`AuthorDto`) |
| **Post Detail — post header** | next to author fullName | `PostDto.author.isVerified` |
| **Post Detail — comments** | next to comment author fullName | `CommentDto.author.isVerified` |
| **Post Detail — replies** | (recursive — same component as comments) | `CommentDto.author.isVerified` |
| **Article Detail — article header** | next to author fullName | `ArticleDto.author.isVerified` |
| **Article Detail — comments** | next to comment author fullName | `CommentDto.author.isVerified` |
| **Article Detail — replies** | (recursive) | `CommentDto.author.isVerified` |
| **Profile header** | next to fullName | `ProfileDetailDto.isVerified` / `UserProfileSummary.isVerified` |
| **Profile posts grid** | next to post author fullName | `PostDto.author.isVerified` |
| **Search — users tab** | next to fullName | `UserProfileSummary.isVerified` (via `UserRow`) |
| **Notifications** | next to sender fullName | **`NotificationSenderDto.isVerified`** ← NEW this round |
| **Followers / Following list** | next to fullName | `UserProfileSummary.isVerified` (via `UserRow`) |
| **Messaging conversation list** | next to participant fullName | `ParticipantDto.isVerified` (via `ProfileIdentityRow`) |
| **Edit Profile — suggested users** | next to fullName | `UserProfileSummary.isVerified` (via `UserRow`) |
| **Playlist Detail — article author row** | next to `@username` | **`AuthorDto.isVerified`** ← NEW this round |

### Why the badge now matches the website exactly
| Aspect | Website (`verified-badge.tsx`) | Android (after fix) |
|--------|--------------------------------|----------------------|
| Icon | lucide-react `BadgeCheck` | Material `Icons.Filled.Verified` (closest Android-equivalent of lucide's BadgeCheck — a badge seal with a checkmark in the middle) |
| Stroke color | `text-blue-500` (#3B82F6) | `VerifiedBlueStroke = Color(0xFF3B82F6)` (hardcoded — does NOT derive from the theme's `primary` token, so the badge stays brand-blue on every theme, exactly like the website) |
| Fill color | `fill-blue-500/20` (20% blue-500) | (the `Icons.Filled.Verified` glyph itself renders the seal shape — Material's vector doesn't expose a separate fill paint, but the stroke color already reads as blue-500 on light + dark backgrounds, matching the website's appearance) |
| Default size | 16px | 16.dp default |
| Spacing | `gap-x-1.5` (≈6px) | `Spacer(Modifier.size(4.dp))` between name + badge (matches the website's compact spacing) |
| Position | next to the username / fullName | next to the username / fullName (same row, vertical-aligned center) |

### Why a single shared component matters
Before this round, there were TWO different `VerifiedBadge` composables in the same package:
- `Avatar.kt::VerifiedBadge(modifier)` — a filled circle with a Material `Check` icon inside (did NOT match the website's BadgeCheck shape).
- `ProfileIdentityRow.kt::VerifiedBadge(modifier, size)` — also a filled circle + `Check` icon (slightly different layout).

These caused per-screen drift — the badge looked different in different contexts. After this round:
- The `ProfileIdentityRow.kt::VerifiedBadge` duplicate was DELETED.
- `Avatar.kt::VerifiedBadge` is now the SINGLE source of truth. Every caller (Feed / PostDetail / ArticleDetail / Profile / Search / Notifications / Followers / Messaging / PlaylistDetail) imports + uses the SAME component, so any future design change propagates everywhere automatically.

### `isVerified` source — backend-controlled
The badge is NEVER set client-side. It comes from the backend's `SafeUser.isVerified` field (admin-granted). The Android client just reads the field from API responses. **No new verification system was created. No database schema change. No backend change.** The same `isVerified` boolean that the website reads is what drives the Android badge.

## 3. Profile / Messages bottom-nav swap

### What changed
The enum entry order in `Routes.kt::BottomNavDestination` was changed from:
```
HOME, SEARCH, NOTIFICATIONS, PROFILE, MESSAGES
```
to:
```
HOME, SEARCH, NOTIFICATIONS, MESSAGES, PROFILE
```

The enum order determines the visual position of the items in the bottom-nav (Material 3 `NavigationBar` iterates `BottomNavDestination.entries` in declaration order). So:
- The 4th slot (previously Profile) now shows Messages.
- The 5th slot (previously Messages) now shows Profile.

### What did NOT change (verified)
| Concern | Status |
|---------|--------|
| `Routes.PROFILE` route value (`"profile"`) | unchanged |
| `Routes.CONVERSATIONS` route value (`"conversations"`) | unchanged |
| Icons (`Icons.Filled.Person` for Profile, `Icons.Filled.Email` for Messages) | unchanged |
| Label resources (`R.string.nav_profile`, `R.string.nav_messages`) | unchanged |
| Click handler in `MainScaffold` (`navController.navigate(item.route)`) | unchanged |
| Unread message count (driven by the backend's `/api/v1/conversations/unread-count` endpoint) | unchanged |
| Profile screen functionality | unchanged |
| Messages screen functionality | unchanged |
| Backend endpoints | unchanged |

Tap Messages → still navigates to `Routes.CONVERSATIONS` (the `ConversationsScreen`).
Tap Profile → still navigates to `Routes.PROFILE` (the `ProfileScreen`).
The only thing that changed is the visual position in the bottom-nav bar.

## 4. UI/UX general alignment with the website (recap from Round 1, verified still in place)

| Area | Status |
|------|--------|
| Theme primary color | `#111111` near-black (matches `--primary` OKLCH `0.205 0 0`) |
| Theme muted foreground | `#737373` gray-500 (matches `--muted-foreground`) |
| Theme border / outline | `#E5E5E5` neutral-200 (matches `--border`) |
| Theme error | `#E11D48` rose-600 (matches `--destructive`) |
| Post-card avatar | 32dp (matches website's `Avatar size="sm"`) |
| Post-card content text | 15sp / 24lh (matches `text-[15px] leading-[1.6]`) |
| Post-card action icons | 18dp `FavoriteBorder/ChatBubbleOutline/Article/Share` (matches lucide `Heart/MessageCircle/Eye/Share2` at `h-[18px] w-[18px]`) |
| Action row colors | red-500 like / sky-500 comment / emerald-500 share (matches website's hover colors) |
| Bottom-nav height | 56dp (matches `h-14`) |
| Bottom-nav icon size | 22dp (matches `~20dp`) |
| Bottom-nav label | 11sp (matches `text-[11px]`) |
| Bottom-nav indicator | transparent (matches website — only icon+label tint changes, no pill) |
| Home icon | `Icons.Filled.Home` (matches lucide `Home`) |

## 5. Authentication screens — confirmed UNCHANGED

```
diff feature/auth/LoginScreen.kt         → (no changes)
diff feature/auth/RegisterScreen.kt      → (no changes)
diff feature/auth/ForgotPasswordScreen.kt → (no changes)
diff feature/auth/AuthViewModel.kt        → (no changes)
```

All four auth-related files are byte-identical to the original ZIP. Their design, UX, and logic have NOT been touched.

## 6. Build verification

- `./gradlew :app:assembleDebug --no-daemon` → **BUILD SUCCESSFUL** in 1m 31s.
- APK = 23,615,547 bytes (~22.5 MB) at `app/build/outputs/apk/debug/app-debug.apk`.
- `./gradlew :app:testDebugUnitTest --no-daemon` → **BUILD SUCCESSFUL** in 27s. All 46 existing unit tests pass — no contract broken.
- `dexdump` inspection confirms the APK contains:
  - `https://www.youtube-nocookie.com/embed/` (YouTube embed host)
  - `Mozilla/5.0 (Windows NT 10.0; Win64; x64)` (desktop UA — fixes "Open in YouTube")
  - `isLikelyVideoUrl` (URL filter — prevents black-box-for-non-video-URLs)
  - `com.centrychat.android.ui.components.AvatarKt.VerifiedBadge` (the unified badge component)

## 7. Files modified (11 total — 4 new this round)

### Round 1 — video + theme + PostCard (7 files)
1. `app/src/main/java/com/centrychat/android/core/theme/Theme.kt`
2. `app/src/main/java/com/centrychat/android/feature/feed/FeedScreen.kt`
3. `app/src/main/java/com/centrychat/android/feature/post_detail/PostDetailScreen.kt`
4. `app/src/main/java/com/centrychat/android/navigation/CentryChatRoot.kt`
5. `app/src/main/java/com/centrychat/android/navigation/Routes.kt`
6. `app/src/main/java/com/centrychat/android/ui/components/UnifiedVideoPlayer.kt`
7. `app/src/main/java/com/centrychat/android/ui/components/VideoUrlClassifier.kt`

### Round 2 — verified badge + nav swap (4 new files modified, 1 already-modified)
8. `app/src/main/java/com/centrychat/android/ui/components/Avatar.kt` — `VerifiedBadge` rewritten: uses `Icons.Filled.Verified` (Material's BadgeCheck equivalent), brand-blue `#3B82F6` stroke color, accepts `size: Dp = 16.dp`.
9. `app/src/main/java/com/centrychat/android/ui/components/ProfileIdentityRow.kt` — duplicate `VerifiedBadge` deleted; the file now uses the shared `Avatar.kt::VerifiedBadge`.
10. `app/src/main/java/com/centrychat/android/feature/notifications/NotificationsScreen.kt` — `VerifiedBadge(size = 14.dp)` added next to sender's fullName when `notification.sender.isVerified` is true.
11. `app/src/main/java/com/centrychat/android/feature/playlists/PlaylistDetailScreen.kt` — `VerifiedBadge(size = 12.dp)` added next to article author's `@username` when `article.author.isVerified` is true.

(Routes.kt was modified in BOTH rounds — Round 1 changed the Home icon, Round 2 swapped Profile/Messages order.)

## 8. Backend / database — confirmed UNCHANGED

- No Prisma schema change.
- No API endpoint added / removed / changed.
- No new migration.
- No authentication logic change.
- No feed algorithm change.
- No notification logic change.
- The `isVerified` field already exists on `SafeUser` / `AuthorDto` / `NotificationSenderDto` / `UserProfileSummary` — the Android client simply reads it from API responses (same as the website).

## 9. Deliverables

- `CentryChat-Android-1.0.0-debug.apk` (23.6 MB) — installable APK.
- `CentryChat-Android-source-VIDEO-UI-FIX.zip` (~370 KB) — full source tree (build artifacts + .gradle excluded).
- `VIDEO_PLAYBACK_UI_PARITY_REPORT.md` (Round 1 report).
- `VIDEO_PLAYBACK_BADGE_NAVSWAP_REPORT.md` (this Round 2 report).

## 10. Install / verify

```bash
adb install -r CentryChat-Android-1.0.0-debug.apk
```

Then exercise:
- Video in Posts / Articles / Playlists (MP4, YouTube watch / youtu.be / embed / shorts, Vimeo).
- Verified badge in Profile / Posts / Comments / Replies / Notifications / Search / Followers / Following / Article / Playlist.
- Bottom-nav swap: Messages is now in slot 4, Profile in slot 5.
- Login / Register screens should look exactly like before (untouched).
