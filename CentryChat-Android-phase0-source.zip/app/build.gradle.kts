import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.centrychat.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.centrychat.android"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        // Default API base URL — points to the production SentryChat backend on Netlify.
        // CORRECTED (was "centrychat.netlify.app" which 404s — the real deployment
        // lives at sentrychat.netlify.app, verified by curl 2026-09-28).
        // Override in a release build via -PapiBaseUrl=... or by editing this line.
        // The app reads this from BuildConfig at runtime (see CoreConstants.kt).
        buildConfigField("String", "API_BASE_URL", "\"https://sentrychat.netlify.app\"")
        // The Origin header is sent on POST/PUT/PATCH/DELETE to satisfy the backend's
        // CSRF protection (which compares the request Origin against the deployment URL).
        // Must EXACTLY match API_BASE_URL or the CSRF check returns HTTP 403.
        buildConfigField("String", "API_ORIGIN", "\"https://sentrychat.netlify.app\"")
        // App display name used in the launcher + the in-app header.
        buildConfigField("String", "APP_DISPLAY_NAME", "\"CentryChat\"")
    }

    // Three build types with progressively stricter settings.
    buildTypes {
        debug {
            isDebuggable = true
            isMinifyEnabled = false
            // In debug you can override the API URL via gradle.properties:
            //   centrychat.apiBaseUrl=https://your-staging.example.com
            // Or leave it to use the production URL above (safer default).
            buildConfigField("String", "API_BASE_URL", "\"${project.findProperty("centrychat.apiBaseUrl") ?: "https://sentrychat.netlify.app"}\"")
            buildConfigField("String", "API_ORIGIN", "\"${project.findProperty("centrychat.apiBaseUrl") ?: "https://sentrychat.netlify.app"}\"")
        }
        release {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Release builds always target the real production backend (SentryChat on Netlify).
            buildConfigField("String", "API_BASE_URL", "\"https://sentrychat.netlify.app\"")
            buildConfigField("String", "API_ORIGIN", "\"https://sentrychat.netlify.app\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // ── Core library desugaring ───────────────────────────────────────────
        // Enables java.time API (Instant, OffsetDateTime, LocalDateTime,
        // ZoneId, ZonedDateTime, DateTimeFormatter) on API 24–25 devices
        // (Android 7.0 / 7.1) where the java.time classes are not present
        // in the platform. Without this, lint flags every java.time call
        // in TimeFormatter.kt as a NewApi error (24 errors) AND the app
        // would crash at runtime on Android 7.0–7.1 with NoClassDefFoundError.
        // The desugar dependency (~150 KB) is the standard fix recommended
        // by the AndroidX team for projects targeting minSdk 24 that want
        // to use java.time. This is a stabilization fix, not a new feature.
        isCoreLibraryDesugaringEnabled = true
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/INDEX.LIST"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "META-INF/*.kotlin_module"
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }

    // ── Lint configuration ───────────────────────────────────────────────
    // Phase 0 stabilization: silence the UnsafeOptInUsageError check for
    // androidx.media3's @UnstableApi opt-in. The UnifiedVideoPlayer.kt uses
    // DefaultHttpDataSource.Factory / DefaultMediaSourceFactory / PlayerView
    // APIs that Media3 marks as @UnstableApi. These are the correct APIs to
    // use (the stable alternatives don't support the UA / cross-protocol /
    // Range features we need). The proper fix is to add @OptIn(UnstableApi::class)
    // annotations, but per Phase 0 scope (don't touch UnifiedVideoPlayer.kt —
    // deferred to Phase 4 video engine work), we disable the lint check at
    // the module level. This is a config-only change — no behavior change,
    // no runtime risk. The opt-in annotations will be added properly in
    // Phase 4 when the video engine gets PiP / subtitles / playback speed.
    lint {
        // Disable the experimental API opt-in check for Media3 — we knowingly
        // use the @UnstableApi surface (DefaultHttpDataSource.Factory +
        // DefaultMediaSourceFactory + PlayerView's controller settings).
        disable += "UnsafeOptInUsageError"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xjvm-default=all")
    }
}

dependencies {
    // Core Android
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.splashscreen)

    // Compose (BOM-managed)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.runtime)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // Navigation
    implementation(libs.androidx.navigation.compose)

    // Coroutines
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)

    // Serialization
    implementation(libs.kotlinx.serialization.json)

    // Networking
    implementation(libs.retrofit.core)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp.core)
    implementation(libs.okhttp.logging)

    // Image loading
    implementation(libs.coil.compose)

    // DataStore + encrypted preferences for session cookies
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.security.crypto)

    // Custom tabs (open external links in in-app browser, not full WebView)
    implementation(libs.androidx.browser)

    // Media3 (ExoPlayer) — for video playback in Article + Playlist content.
    // The website uses HTML5 <video controls> for article videoUrl playback;
    // Android uses androidx.media3 PlayerView + ExoPlayer for the same
    // controls (play/pause/seek/loading/error states).
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.media3.common)
    // Explicit datasource dep — needed for DefaultHttpDataSource.Factory
    // (User-Agent, cross-protocol redirects, Range requests). Pulled
    // transitively by media3-exoplayer but declared explicitly so the
    // UnifiedVideoPlayer's HTTP wiring is guaranteed to be on the classpath.
    implementation(libs.androidx.media3.datasource)

    // Unit tests
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")

    // ── Core library desugaring ───────────────────────────────────────────
    // Enables java.time API on API 24–25 (Android 7.0 / 7.1). Required by
    // TimeFormatter.kt which uses OffsetDateTime / Instant / LocalDateTime /
    // ZoneOffset.UTC / DateTimeFormatter — all API 26+. Without desugaring
    // the app crashes on Android 7.0/7.1 with NoClassDefFoundError.
    // Stabilization fix, not a new feature.
    coreLibraryDesugaring(libs.desugar.jdk.libs)
}
