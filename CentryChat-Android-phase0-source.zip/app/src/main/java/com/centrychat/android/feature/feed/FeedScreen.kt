package com.centrychat.android.feature.feed

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.data.model.FeedItemDto
import com.centrychat.android.rememberFeedViewModel
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter

/**
 * The home feed screen.
 *
 * Renders the unified feed (posts + articles merged + ranked by the backend's
 * recommendation algorithm). The client does NOT re-rank — it renders items
 * in the order the backend returns them.
 *
 * Supports:
 *  - Pull-to-refresh (via [refresh] callback).
 *  - Infinite scroll (triggers [loadMore] when the user is near the end).
 *  - Empty state (when the user follows no one + has no interests).
 *  - Error state (when the network fails — provides a Retry button).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    contentPadding: PaddingValues,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    val viewModel = rememberFeedViewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    // Trigger loadMore when the user scrolls near the end.
    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisibleIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisibleIndex >= total - 3
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadMore()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.feed_title),
                        fontWeight = FontWeight.Bold,
                    )
                },
            )
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                state.isLoading && state.items.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                state.error != null && state.items.isEmpty() -> {
                    ErrorState(
                        message = state.error!!,
                        onRetry = viewModel::refresh,
                    )
                }
                state.isEmpty -> {
                    EmptyState(message = stringResource(R.string.feed_empty))
                }
                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(state.items) { item ->
                            FeedItemRow(
                                item = item,
                                onPostClick = onPostClick,
                                onArticleClick = onArticleClick,
                                onUserClick = onUserClick,
                            )
                        }
                        if (state.isLoadingMore) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    CircularProgressIndicator()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedItemRow(
    item: FeedItemDto,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    when {
        item.post != null -> PostCard(
            post = item.post,
            onClick = { onPostClick(item.post.id) },
            onUserClick = onUserClick,
        )
        item.article != null -> ArticleCard(
            article = item.article,
            onClick = { onArticleClick(item.article.id) },
            onUserClick = onUserClick,
        )
    }
}

@Composable
private fun PostCard(
    post: com.centrychat.android.data.model.PostDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    // ── Card mirroring website PostCard (px: py-5, hover:bg-accent/5) ──
    // The website's PostCard is an <article className="px-4 py-5 ..."> with
    // a flex gap-3 layout: avatar (sm=32dp) | content (flex-1). The action
    // row sits below the content with `border-t border-border/40 pt-1` and
    // uses -ml-1 to align full-bleed with the post edges.
    //
    // We mirror the same structure: vertical padding = 20dp (py-5), horizontal
    // padding = 16dp (px-4 → matches md:px-6 later), gap = 12dp (gap-3).
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
        ),
        elevation = androidx.compose.material3.CardDefaults.cardElevation(
            defaultElevation = 0.dp,
        ),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 20.dp)) {
            // Author row — avatar + (name + verified + @username + time) | right-side actions
            Row(
                verticalAlignment = Alignment.Top,
                modifier = Modifier.fillMaxWidth(),
            ) {
                CentryChatAvatar(
                    fullName = post.author.fullName,
                    avatarColor = post.author.avatarColor,
                    avatarUrl = post.author.avatarUrl,
                    onClick = { onUserClick(post.author.username) },
                    size = 32.dp,
                )
                Spacer(Modifier.size(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    // Top row: name + verified badge + @username · timestamp
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = post.author.fullName,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                        )
                        if (post.author.isVerified) {
                            VerifiedBadge()
                        }
                        Text(
                            text = "@${post.author.username}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = "·",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = TimeFormatter.relative(post.createdAt),
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    // Content text — matches website's `text-[15px] leading-[1.6]`
                    Text(
                        text = post.content,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 15.sp,
                            lineHeight = 24.sp,
                        ),
                    )

                    // ── Inline media from Post.content URLs (Post Video fix) ────
                    //
                    // CRITICAL FIX: previously EVERY URL in post.content
                    // got a UnifiedVideoPlayer rendered — even non-video URLs
                    // like `https://github.com/...`. That caused:
                    //   1. A loading spinner (calling the resolver) for
                    //      every URL, even plain webpages
                    //   2. A black 16:9 box with "Open original" button for
                    //      URLs the resolver couldn't classify as video
                    //   3. Users perceived this as "video that doesn't play"
                    //
                    // NEW behavior: filter URLs at extraction time using
                    // VideoUrlClassifier.isLikelyVideoUrl() — only render a
                    // player widget for URLs whose structure signals video
                    // (YouTube, Vimeo, direct .mp4/.m3u8/.mpd/etc.). Non-video
                    // URLs are NOT rendered as players — they're left as
                    // plain text inside the post content (the website renders
                    // them as plain `<a target="_blank">` links, no special
                    // widget).
                    //
                    // Up to 4 URLs are rendered (to avoid an explosion of
                    // players in a Post that links 10 things). De-duplication
                    // is handled inside TextUtils.extractUrls.
                    val postUrls = remember(post.id, post.content) {
                        com.centrychat.android.core.util.TextUtils.extractUrls(post.content)
                            .filter {
                                com.centrychat.android.ui.components.VideoUrlClassifier
                                    .isLikelyVideoUrl(it)
                            }
                            .take(4)
                    }
                    postUrls.forEach { url ->
                        Spacer(Modifier.height(8.dp))
                        com.centrychat.android.ui.components.UnifiedVideoPlayer(
                            rawUrl = url,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            // ── Action row — mirrors website PostActions ───────────────────
            // Website uses: Heart | MessageCircle | Eye (views) | Share2 |
            // BookmarkPlus (save). Each is h-[18px] w-[18px] in a flex-1
            // button with text-[13px] font-medium text-muted-foreground.
            // Active like = red-500 fill. We mirror this layout.
            androidx.compose.foundation.layout.Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(0.dp),
            ) {
                EngagementAction(
                    icon = Icons.Filled.FavoriteBorder,
                    activeIcon = Icons.Filled.Favorite,
                    count = post.likeCount,
                    active = post.isLiked,
                    activeTint = Color(0xFFEF4444), // red-500
                    modifier = Modifier.weight(1f),
                )
                EngagementAction(
                    icon = Icons.Filled.ChatBubbleOutline,
                    count = post.commentCount,
                    activeTint = Color(0xFF0EA5E9), // sky-500
                    modifier = Modifier.weight(1f),
                )
                EngagementAction(
                    icon = Icons.AutoMirrored.Filled.Article,
                    count = post.viewCount,
                    activeTint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                EngagementAction(
                    icon = Icons.Filled.Share,
                    count = post.shareCount,
                    activeTint = Color(0xFF10B981), // emerald-500
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

/**
 * Engagement action button — mirrors the website's PostActions buttons.
 * - icon size 18dp
 * - text 13sp medium muted-foreground
 * - flex-1 fillMaxWidth (so all actions are equal width + evenly spaced)
 * - active state colors the icon (red for like, sky-500 for comment, etc.)
 * - hover/pressed background = accent/50 (we use a soft ripple)
 */
@Composable
private fun EngagementAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
    activeIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    activeTint: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        modifier = modifier.padding(vertical = 8.dp),
    ) {
        Icon(
            imageVector = if (active && activeIcon != null) activeIcon else icon,
            contentDescription = null,
            tint = if (active) activeTint else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
        if (count > 0) {
            Spacer(Modifier.size(6.dp))
            Text(
                text = com.centrychat.android.core.util.TextUtils.compactCount(count),
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                ),
                color = if (active) activeTint else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ArticleCard(
    article: com.centrychat.android.data.model.ArticleCardDto,
    onClick: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    androidx.compose.material3.Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Article,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = stringResource(R.string.articles_title),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = article.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            article.excerpt?.let {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = TextUtils.truncate(it, 200),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CentryChatAvatar(
                    fullName = article.author.fullName,
                    avatarColor = article.author.avatarColor,
                    avatarUrl = article.author.avatarUrl,
                    onClick = { onUserClick(article.author.username) },
                    size = 24.dp,
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    text = "@${article.author.username}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                article.readingTime?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${it}m",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

