package com.centrychat.android.data.model

import kotlinx.serialization.Serializable

/**
 * Ad Unit DTOs — mirror the web's `/api/v1/admin/admob/units` + `/apps` + `/settings`
 * endpoints. Used by the Android Admin Dashboard's "Publishing & Ad Units"
 * section (replaces the web's AdMob section with a unified management surface).
 *
 * NOTE: The Android UI calls these endpoints AS-IS — the backend source of truth
 * (AdMobAdUnit / AdMobApp tables + admob.* settings) is shared with the web.
 * No Android-only ad system exists. Changes from Android appear in the web
 * admin instantly, and vice versa.
 */
@Serializable
data class AdUnitDto(
    val id: String,
    val name: String,
    val description: String? = null,
    val platform: String,                 // "ANDROID" | "IOS"
    val adUnitId: String,                 // ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ
    val format: String,                   // BANNER | INTERSTITIAL | REWARDED | NATIVE | APP_OPEN
    val placement: String,                // APP_HOME_TOP, APP_FEED, APP_ARTICLE_TOP, ...
    val priority: Int = 10,
    val active: Boolean,
    val environment: String,              // ALL | DEVELOPMENT | PRODUCTION
    val fallbackAdUnitId: String? = null,
    val createdAt: String,
    val updatedAt: String,
)

@Serializable
data class AdMobAppDto(
    val id: String,
    val platform: String,                 // "ANDROID" | "IOS"
    val appName: String,
    val packageName: String? = null,
    val admobAppId: String,
    val enabled: Boolean,
    val createdAt: String,
    val updatedAt: String,
)

@Serializable
data class AdMobSettingsDto(
    val enabled: Boolean,
    val configVersion: Int,
    val environment: String,              // "development" | "production"
    val androidMinVersion: String,
    val iosMinVersion: String,
)

/** GET /api/v1/admin/admob/units → { ok:true, data:{ units:[...] } } */
@Serializable
data class AdUnitsListResponse(
    val units: List<AdUnitDto> = emptyList(),
)

/** GET /api/v1/admin/admob/units/{id} / POST /api/v1/admin/admob/units → { ok:true, data:{ unit:{...}, duplicateWarning:? } } */
@Serializable
data class AdUnitResponse(
    val unit: AdUnitDto,
    val duplicateWarning: String? = null,
)

/** GET /api/v1/admin/admob/apps → { ok:true, data:{ apps:[...] } } */
@Serializable
data class AdMobAppsResponse(
    val apps: List<AdMobAppDto> = emptyList(),
)

/** GET /api/v1/admin/admob/settings → { ok:true, data:{ settings:{...} } } */
@Serializable
data class AdMobSettingsResponse(
    val settings: AdMobSettingsDto,
)

/** PUT /api/v1/admin/admob/apps → { ok:true, data:{ app:{...} } } */
@Serializable
data class AdMobAppUpdateResponse(
    val app: AdMobAppDto,
)

/** Body for POST /api/v1/admin/admob/units (create). */
@Serializable
data class AdUnitCreateBody(
    val name: String,
    val platform: String,
    val adUnitId: String,
    val format: String,
    val placement: String,
    val description: String? = null,
    val priority: Int = 10,
    val active: Boolean = true,
    val environment: String = "ALL",
    val fallbackAdUnitId: String? = null,
)

/** Body for PATCH /api/v1/admin/admob/units/{id} (partial update).
 *  Null fields are omitted from the request body so the backend keeps
 *  the existing value (per the web's `parseJsonBody<...>` semantics). */
@Serializable
data class AdUnitUpdateBody(
    val name: String? = null,
    val description: String? = null,
    val adUnitId: String? = null,
    val format: String? = null,
    val placement: String? = null,
    val priority: Int? = null,
    val active: Boolean? = null,
    val environment: String? = null,
    val fallbackAdUnitId: String? = null,
)

/** Body for PUT /api/v1/admin/admob/apps. */
@Serializable
data class AdMobAppUpdateBody(
    val platform: String,
    val appName: String? = null,
    val packageName: String? = null,
    val admobAppId: String? = null,
    val enabled: Boolean? = null,
)

/** Body for PUT /api/v1/admin/admob/settings. */
@Serializable
data class AdMobSettingsUpdateBody(
    val enabled: Boolean? = null,
    val environment: String? = null,
    val androidMinVersion: String? = null,
    val iosMinVersion: String? = null,
)
