package com.centrychat.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.theme.CentryChatTheme
import com.centrychat.android.navigation.CentryChatRoot

/**
 * The single launcher activity.
 *
 * Responsibilities:
 *  1. Installs the Android 12+ SplashScreen API (no-op on older versions,
 *     but the theme swap still happens via Theme.CentryChat.Splash).
 *  2. Enables edge-to-edge layout (status + navigation bars are transparent
 *     and tinted by [CentryChatTheme]).
 *  3. Mounts the Compose root — [CentryChatRoot] which contains the
 *     NavHost + auth gate + bottom navigation.
 *
 * The activity itself is intentionally minimal. All state + logic lives in
 * ViewModels + the navigation graph. No state is held in this class.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install the splash-screen BEFORE super.onCreate — the splash
        // hand-off requires it to be the first thing set up.
        installSplashScreen()

        super.onCreate(savedInstanceState)

        // Edge-to-edge: content draws behind the system bars. The system bar
        // icons are tinted by the theme based on the current color scheme.
        enableEdgeToEdge()

        // Resolve the AppContainer from the application instance. We pass
        // it down only as far as necessary (the root Composable) so that
        // Compose code can construct ViewModels with their dependencies.
        val appContainer: AppContainer = (application as CentryChatApp).appContainer

        setContent {
            CompositionLocalProvider(LocalAppContainer provides appContainer) {
                CentryChatTheme {
                    CentryChatRoot(appContainer = appContainer)
                }
            }
        }
    }
}
