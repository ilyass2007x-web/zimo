package com.centrychat.android.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.SearchAllResponse
import com.centrychat.android.data.repository.SearchRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: SearchRepository = appContainer.searchRepository

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _state = MutableStateFlow<UiState<SearchAllResponse>>(UiState.Empty)
    val state: StateFlow<UiState<SearchAllResponse>> = _state.asStateFlow()

    private var searchJob: Job? = null

    fun onQueryChange(value: String) {
        _query.value = value
        if (value.isBlank()) {
            _state.value = UiState.Empty
            return
        }
        // Debounce: wait 350ms after the user stops typing before firing.
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(350)
            performSearch(value)
        }
    }

    private suspend fun performSearch(q: String) {
        _state.value = UiState.Loading
        try {
            val response = repo.searchAll(q, limit = 20)
            _state.value = if (response.users.isEmpty() && response.posts.isEmpty() && response.articles.isEmpty()) {
                UiState.Empty
            } else {
                UiState.Success(response)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _state.value = UiState.Error(e.message ?: "Search failed.")
        }
    }
}
