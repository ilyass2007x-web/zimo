package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The user identity returned by the backend's auth endpoints.
 *
 * Mirrors the `SafeUser` type in `src/lib/auth/index.ts` of the CentryChat
 * web project. All fields are nullable-safe — the backend may omit optional
 * fields. The kotlinx-serialization `ignoreUnknownKeys = true` flag in
 * [com.centrychat.android.core.network.RetrofitFactory] handles extra fields
 * gracefully.
 *
 * `username` HAS A DEFAULT (empty string) because the backend's
 * /api/v1/auth/register endpoint returns a REDUCED user object:
 *     `{ id, email, fullName, role }`
 * (only 4 fields) — without `username`. The login + auth/me endpoints return
 * the full SafeUser with `username` populated. When the register response is
 * deserialized, `username` defaults to "" — the AuthRepository then calls
 * /api/v1/auth/me immediately after register to fetch the full user (with
 * username) and replaces the cached user, so the UI never shows "@" with
 * an empty handle for long.
 */
@Serializable
data class UserDto(
    val id: String,
    val fullName: String,
    val email: String,
    val username: String = "",
    @SerialName("emailVerified") val emailVerified: String? = null,
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
    @SerialName("twoFactorEnabled") val twoFactorEnabled: Boolean = false,
    val bio: String? = null,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    val language: String = "en",
    @SerialName("createdAt") val createdAt: String = "",
)

/**
 * The minimal public profile returned by `GET /api/v1/users/{username}/profile`.
 *
 * Mirrors `UserProfileSummary` in `src/lib/follow.ts`. Note that the public
 * profile intentionally does NOT include `email`, `gender`, or `dateOfBirth` —
 * the backend redacts these for privacy.
 *
 * NOTE: The backend wraps this under `data.profile` (not directly under
 * `data`), so the API interface returns [UserProfileResponse] and the
 * repository extracts `.profile` from it. See [UserProfileResponse].
 */
@Serializable
data class UserProfileSummary(
    val id: String,
    val fullName: String,
    val username: String,
    val avatarColor: String? = null,
    val avatarUrl: String? = null,
    val isVerified: Boolean = false,
    val bio: String? = null,
    @SerialName("followersCount") val followersCount: Long = 0,
    @SerialName("followingCount") val followingCount: Long = 0,
    @SerialName("postsCount") val postsCount: Long = 0,
    val isFollowing: Boolean = false,
    val isFollowedBy: Boolean = false,
)

/**
 * Response wrapper for `GET /api/v1/users/{username}/profile`.
 *
 * The backend returns:
 *   `{ "ok": true, "data": { "profile": { id, fullName, username, ... } } }`
 *
 * The inner `profile` object IS the [UserProfileSummary]. Without this
 * wrapper, kotlinx-serialization tried to deserialize `data` directly into
 * `UserProfileSummary` and crashed with:
 *   `Fields [id, fullName, username] are required for type with serial
 *    name 'UserProfileSummary', but they were missing at path: $.data`
 * because `data` actually contains a `profile` field, not the profile's
 * fields directly.
 */
@Serializable
data class UserProfileResponse(
    val profile: UserProfileSummary,
)

/**
 * The richer profile returned by `GET /api/v1/profile` (the current user's
 * own profile). Includes `email`, `language`, `notificationPrefs`, etc.
 * that are NEVER returned for other users.
 */
@Serializable
data class ProfileResponse(
    val user: ProfileDetailDto? = null,
)

@Serializable
data class ProfileDetailDto(
    val id: String,
    val fullName: String,
    val email: String,
    val username: String,
    val bio: String? = null,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val isVerified: Boolean = false,
    val role: String = "USER",
    val status: String = "ACTIVE",
    val language: String = "en",
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    @SerialName("notificationPrefs") val notificationPrefs: NotificationPrefs? = null,
)

@Serializable
data class NotificationPrefs(
    val message: Boolean = true,
    val security: Boolean = true,
    val system: Boolean = true,
    val account: Boolean = true,
    val moderation: Boolean = true,
)
