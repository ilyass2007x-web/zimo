package com.centrychat.android.core

import androidx.compose.runtime.staticCompositionLocalOf

/**
 * CompositionLocal that exposes the [AppContainer] to the entire Compose tree.
 *
 * Set in MainActivity via `CompositionLocalProvider(LocalAppContainer provides container)`.
 * Any composable that needs direct access (rare — most go through a ViewModel)
 * can read it via `LocalAppContainer.current`.
 */
val LocalAppContainer = staticCompositionLocalOf<AppContainer> {
    error("AppContainer not provided — wrap your UI in CompositionLocalProvider(LocalAppContainer provides appContainer)")
}
