package com.centrychat.android.feature.playlists

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.repository.PlaylistsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PlaylistsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PlaylistsRepository = appContainer.playlistsRepository

    private val _state = MutableStateFlow<UiState<List<PlaylistDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<PlaylistDto>>> = _state.asStateFlow()

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val list = repo.getPlaylists().playlists
                _state.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load playlists.")
            }
        }
    }

    fun create(name: String, description: String?) {
        viewModelScope.launch {
            try { repo.createPlaylist(name, description); load() } catch (_: Exception) {}
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            try { repo.deletePlaylist(id); load() } catch (_: Exception) {}
        }
    }
}
