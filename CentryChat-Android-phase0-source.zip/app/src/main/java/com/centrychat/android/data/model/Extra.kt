package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Search suggestions response — `GET /api/v1/search/suggest`.
 * Backend returns: `{"ok":true,"data":{"users":[...],"posts":[...],"articles":[...]}}`
 */
@Serializable
data class SuggestResponse(
    val users: List<UserProfileSummary> = emptyList(),
    val posts: List<PostDto> = emptyList(),
    val articles: List<ArticleCardDto> = emptyList(),
)

/**
 * Search history response — `GET /api/v1/search-history`.
 * Backend returns: `{"ok":true,"data":{"history":[{...}]}}`
 */
@Serializable
data class SearchHistoryResponse(
    val history: List<SearchHistoryItem> = emptyList(),
)

@Serializable
data class SearchHistoryItem(
    val id: String,
    val query: String,
    @SerialName("createdAt") val createdAt: String = "",
)

// ────────────────────────────────────────────────────────────────────
// Username check (registration form)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class UsernameCheckRequest(
    val username: String,
)

/**
 * Response: `{"ok":true,"data":{"available":true,"suggestions":["..."]}}`
 */
@Serializable
data class UsernameCheckResponse(
    val available: Boolean = false,
    val suggestions: List<String> = emptyList(),
)

// ────────────────────────────────────────────────────────────────────
// Topics
// ────────────────────────────────────────────────────────────────────

@Serializable
data class TopicsListResponse(
    val topics: List<TopicDto> = emptyList(),
)

@Serializable
data class TopicDto(
    val id: String,
    val slug: String,
    val name: String,
    val description: String? = null,
    val isActive: Boolean = true,
    @SerialName("isFollowing") val isFollowing: Boolean = false,
    @SerialName("followersCount") val followersCount: Long = 0,
    @SerialName("postsCount") val postsCount: Long = 0,
    @SerialName("articlesCount") val articlesCount: Long = 0,
)

@Serializable
data class TopicDetailResponse(
    val topic: TopicDto,
)

// ────────────────────────────────────────────────────────────────────
// Collections (save-for-later of posts/articles/profiles)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class CollectionsListResponse(
    val collections: List<CollectionDto> = emptyList(),
)

@Serializable
data class CollectionDto(
    val id: String,
    val name: String,
    val description: String? = null,
    val visibility: String = "PRIVATE",
    @SerialName("itemsCount") val itemsCount: Long = 0,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
)

@Serializable
data class CollectionItemsResponse(
    val items: List<CollectionItemDto> = emptyList(),
)

@Serializable
data class CollectionItemDto(
    val id: String,
    val itemType: String,
    val itemId: String,
    @SerialName("addedAt") val addedAt: String = "",
    // Polymorphic payload — only one populated depending on itemType
    val post: PostDto? = null,
    val article: ArticleCardDto? = null,
    val profile: UserProfileSummary? = null,
)

// ────────────────────────────────────────────────────────────────────
// Playlists (ordered list of articles)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class PlaylistsListResponse(
    val playlists: List<PlaylistDto> = emptyList(),
)

/**
 * A single playlist row — mirrors `serializePlaylist` in
 * src/lib/playlists/index.ts (the backend's canonical serializer).
 *
 * IMPORTANT — backend field names (NOT arbitrary choices):
 *  - `id`           — playlist's primary key (CUID)
 *  - `ownerId`      — the playlist owner's user ID (NOT included in the
 *                     Android DTO because the UI doesn't use it — the
 *                     owner's name is rendered via the embedded `owner`
 *                     object on the detail endpoint)
 *  - `name`         — playlist display name
 *  - `slug`         — URL-safe slug (immutable after creation)
 *  - `description`  — long-form description (nullable)
 *  - `coverImage`   — optional cover image URL (Pinterest or direct image)
 *  - `isPublic`     — backend visibility flag (true = public, false = private).
 *                     Mapped to `visibility` via @SerialName("isPublic") so
 *                     the Android UI keeps its existing `visibility` property.
 *  - `createdAt`    — ISO timestamp
 *  - `updatedAt`    — ISO timestamp (nullable on the wire — set to "" when null)
 *  - `itemCount`    — total number of items in the playlist (denormalized
 *                     count from the backend's `_count.items`). Mapped to
 *                     `itemsCount` via @SerialName("itemCount") so the
 *                     existing UI code keeps its property name.
 *
 * The previous version of this DTO used `visibility` (default "PRIVATE")
 * and `itemsCount` (default 0) WITHOUT @SerialName — meaning the backend's
 * `isPublic` boolean was SILENTLY DROPPED (the Json config's
 * `ignoreUnknownKeys = true` swallowed the unknown key), and `itemsCount`
 * was always 0 because the backend sends `itemCount` instead.
 */
@Serializable
data class PlaylistDto(
    val id: String,
    val name: String,
    val slug: String,
    val description: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    /** Backend sends `isPublic: boolean`. We expose it as `isPublic`
     *  directly — the previous `visibility: String` field didn't
     *  deserialize because the backend sends a boolean, not a string.
     *  Callers that need a string ("PUBLIC"/"PRIVATE") can derive it
     *  via `if (isPublic) "PUBLIC" else "PRIVATE"`. */
    @SerialName("isPublic") val isPublic: Boolean = false,
    /** Backend sends `itemCount: number`. Maps to Android's `itemsCount`. */
    @SerialName("itemCount") val itemsCount: Long = 0,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
) {
    /** Convenience: returns "PUBLIC" when [isPublic] is true, else "PRIVATE".
     *  Matches the legacy string representation used by some older callers. */
    val visibility: String get() = if (isPublic) "PUBLIC" else "PRIVATE"
}

/**
 * Response wrapper for `GET /api/v1/playlists/{id}` (single playlist).
 *
 * The backend returns:
 *   `{ "ok": true, "data": { "playlist": { id, name, slug, ... } } }`
 *
 * The inner `playlist` object IS the [PlaylistDto]. Without this
 * wrapper, kotlinx-serialization tried to deserialize `data` directly
 * into `PlaylistDto` and crashed with:
 *   `Fields [id, name, slug] are required for type with serial name
 *    'com.centrychat.android.data.model.PlaylistDto', but they were
 *    missing at path: S.data`
 * because `data` actually contains a `playlist` field, not the
 * playlist's fields directly.
 *
 * Backend source: src/app/api/v1/playlists/[id]/route.ts →
 *   `return ok({ playlist: serializePlaylist(playlist) })`.
 */
@Serializable
data class PlaylistDetailResponse(
    val playlist: PlaylistDto? = null,
)

@Serializable
data class PlaylistItemsResponse(
    val items: List<PlaylistItemDto> = emptyList(),
)

/**
 * A single row in a playlist's items list.
 *
 * Mirrors the shape returned by `GET /api/v1/playlists/{id}/items` (see
 * src/app/api/v1/playlists/[id]/items/route.ts → `ok({ items: ... })`).
 * Each row has the bare playlist-item fields (id, playlistId, articleId,
 * position, addedAt) PLUS a `article` field with the hydrated Article
 * data (title, excerpt, coverImage, videoUrl, imageZoom, imagePositionX,
 * imagePositionY, publishedAt, readingTime, author).
 *
 * IMPORTANT: the backend's `article` field is a `HydratedArticle` (see
 * src/lib/playlists/index.ts → hydratePlaylistItems), NOT an
 * `ArticleCardDto`. The HydratedArticle uses `articleId` (the FK column
 * in the DB) instead of `id`, and does NOT include engagement counters
 * (likeCount, commentCount, viewCount, shareCount, isLiked) because
 * those are not needed for the playlist-items view. We model it with a
 * separate [PlaylistArticleDto] so deserialization does NOT crash on
 * the missing required `id` field of [ArticleCardDto].
 *
 * The previous version declared `article: ArticleCardDto? = null`, which
 * made kotlinx-serialization throw `Fields [id] are required for
 * ArticleCardDto` because the backend's hydrated-article object has
 * `articleId`, not `id`. As a result the entire items list failed to
 * deserialize → the playlist detail screen appeared empty even though
 * the backend had items. This is the root cause of the "Playlist
 * content does not show" bug.
 */
@Serializable
data class PlaylistItemDto(
    val id: String,
    @SerialName("playlistId") val playlistId: String? = null,
    val articleId: String,
    val position: Long = 0,
    @SerialName("addedAt") val addedAt: String = "",
    val article: PlaylistArticleDto? = null,
)

/**
 * The hydrated Article data embedded in each playlist item.
 *
 * Mirrors `HydratedArticle` in src/lib/playlists/index.ts. The field is
 * called `articleId` (the DB column name) on the backend — we expose it
 * as both `articleId` (raw) AND `id` (computed) so callers can use the
 * same field name as [ArticleCardDto].
 *
 * NOTE: this DTO intentionally does NOT include `likeCount`,
 * `commentCount`, `viewCount`, `shareCount`, `isLiked` — the backend's
 * hydrate function doesn't fetch those. If the Android UI needs them
 * for a richer card, it can call `GET /api/v1/articles/{articleId}`
 * separately (returns the full ArticleDetailDto with all counters).
 */
@Serializable
data class PlaylistArticleDto(
    /**
     * The article's database ID. The backend names this field
     * `articleId` (the FK column), not `id` — we use @SerialName so
     * deserialization matches the backend's JSON shape.
     */
    @SerialName("articleId") val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    val author: AuthorDto? = null,
)

// ────────────────────────────────────────────────────────────────────
// Public site pages (about / privacy / terms / contact)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class SitePageResponse(
    val page: SitePageDto? = null,
)

@Serializable
data class SitePageDto(
    val slug: String,
    val title: String,
    val content: String = "",
    val visibility: String = "PUBLIC",
    @SerialName("seoTitle") val seoTitle: String? = null,
    @SerialName("seoDescription") val seoDescription: String? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("updatedAt") val updatedAt: String? = null,
)

// ────────────────────────────────────────────────────────────────────
// Admin DTOs
// ────────────────────────────────────────────────────────────────────

/**
 * Admin dashboard — `GET /api/v1/admin/dashboard`.
 * Shape: `{"ok":true,"data":{...stats...}}`
 */
@Serializable
data class AdminDashboardResponse(
    val users: AdminUsersStats? = null,
    val content: AdminContentStats? = null,
    val moderation: AdminModerationStats? = null,
    val sessions: AdminSessionsStats? = null,
)

@Serializable
data class AdminUsersStats(
    val total: Long = 0,
    val active: Long = 0,
    val suspended: Long = 0,
    val banned: Long = 0,
    @SerialName("pending_verification") val pendingVerification: Long = 0,
    val newToday: Long = 0,
    val newThisWeek: Long = 0,
)

@Serializable
data class AdminContentStats(
    val posts: Long = 0,
    val articles: Long = 0,
    val pending: Long = 0,
    val flagged: Long = 0,
)

@Serializable
data class AdminModerationStats(
    val pending: Long = 0,
    val reviewed: Long = 0,
    val blocked: Long = 0,
)

@Serializable
data class AdminSessionsStats(
    val active: Long = 0,
    val last24h: Long = 0,
)

@Serializable
data class AdminUsersListResponse(
    val users: List<AdminUserSummary> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminUserSummary(
    val id: String,
    val fullName: String,
    val email: String? = null,
    val username: String = "",
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
)

@Serializable
data class AdminUserDetailResponse(
    val user: AdminUserDetail? = null,
)

@Serializable
data class AdminUserDetail(
    val id: String,
    val fullName: String,
    val email: String? = null,
    val username: String = "",
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val bio: String? = null,
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    val language: String = "en",
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
    @SerialName("twoFactorEnabled") val twoFactorEnabled: Boolean = false,
    val permissions: List<String> = emptyList(),
    @SerialName("moderationHistory") val moderationHistory: List<AdminModerationEvent> = emptyList(),
)

@Serializable
data class AdminModerationEvent(
    val id: String,
    val action: String,
    val reason: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("adminId") val adminId: String? = null,
)

@Serializable
data class AdminContentListResponse(
    val items: List<AdminContentItem> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminContentItem(
    val id: String,
    val type: String,
    val title: String? = null,
    val content: String? = null,
    val excerpt: String? = null,
    val status: String = "PUBLISHED",
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
    val author: AdminUserSummary? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("publishedAt") val publishedAt: String? = null,
)

@Serializable
data class AdminSettingsResponse(
    val settings: List<AdminSettingEntry> = emptyList(),
)

@Serializable
data class AdminSettingEntry(
    val key: String,
    val value: String? = null,
    val type: String = "string",
    val description: String? = null,
    val category: String? = null,
)

@Serializable
data class AdminFeaturesResponse(
    val features: List<AdminFeatureEntry> = emptyList(),
)

@Serializable
data class AdminFeatureEntry(
    val key: String,
    val enabled: Boolean = false,
    val description: String? = null,
)

@Serializable
data class AdminAuditListResponse(
    val logs: List<AdminAuditLog> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminAuditLog(
    val id: String,
    val action: String,
    @SerialName("adminId") val adminId: String? = null,
    @SerialName("adminName") val adminName: String? = null,
    @SerialName("targetType") val targetType: String? = null,
    @SerialName("targetId") val targetId: String? = null,
    val metadata: String? = null,
    @SerialName("ipAddress") val ipAddress: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
)

@Serializable
data class AdminSystemResponse(
    val node: String? = null,
    val uptime: Long = 0,
    val memory: AdminSystemMemory? = null,
    val providers: AdminSystemProviders? = null,
)

@Serializable
data class AdminSystemMemory(
    val rss: Long = 0,
    val heapTotal: Long = 0,
    val heapUsed: Long = 0,
    val external: Long = 0,
)

@Serializable
data class AdminSystemProviders(
    val database: String = "unknown",
    val storage: String = "unknown",
    val email: String = "unknown",
    val cache: String = "unknown",
    val jobs: String = "unknown",
    val realtime: String = "unknown",
)

@Serializable
data class AdminSecurityResponse(
    val headers: Map<String, String> = emptyMap(),
    val rateLimits: Map<String, String> = emptyMap(),
    val audit: AdminSecurityAudit? = null,
)

@Serializable
data class AdminSecurityAudit(
    val totalEvents: Long = 0,
    val last24h: Long = 0,
    val recentActions: List<String> = emptyList(),
)

@Serializable
data class AdminMyPermissionsResponse(
    val role: String = "USER",
    val permissions: List<String> = emptyList(),
    val isSuperAdmin: Boolean = false,
)
