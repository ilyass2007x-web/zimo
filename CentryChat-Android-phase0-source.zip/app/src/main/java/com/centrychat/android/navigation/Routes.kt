package com.centrychat.android.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The navigation routes for the app.
 */
object Routes {

    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    const val RESET_PASSWORD = "reset_password?token={token}"
    const val RESET_PASSWORD_BASE = "reset_password"

    const val HOME = "home"
    const val SEARCH = "search"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"

    const val POST_DETAIL = "post/{postId}"
    const val POST_DETAIL_BASE = "post"
    const val ARTICLE_DETAIL = "article/{articleId}"
    const val ARTICLE_DETAIL_BASE = "article"
    const val USER_PROFILE = "user/{username}"
    const val USER_PROFILE_BASE = "user"
    const val FOLLOWERS = "followers/{username}"
    const val FOLLOWERS_BASE = "followers"
    const val FOLLOWING = "following/{username}"
    const val FOLLOWING_BASE = "following"
    const val EDIT_PROFILE = "edit_profile"

    // ── New routes (feature-parity expansion) ─────────────────────────
    // NOTE: Admin routes have been REMOVED from the Android app (Round 3
    // of the deep-debugging work — the user explicitly requested no
    // admin UI in Android). The backend's admin endpoints are NOT
    // removed — they remain available for the website admin dashboard
    // (which is the sole consumer). The bottom-nav ADMIN entry, the
    // ADMIN_DASHBOARD route, and the ADMIN_SECTION composable have all
    // been removed from the Android navigation graph so even an admin
    // user logging in to Android sees only the regular app UI (no admin
    // dashboard, no admin section screens, no admin-only buttons).
    const val TOPICS = "topics"
    const val TOPIC_DETAIL = "topic/{slug}"
    const val TOPIC_DETAIL_BASE = "topic"
    const val COLLECTIONS = "collections"
    const val COLLECTION_DETAIL = "collection/{id}"
    const val COLLECTION_DETAIL_BASE = "collection"
    const val PLAYLISTS = "playlists"
    const val PLAYLIST_DETAIL = "playlist/{id}"
    const val PLAYLIST_DETAIL_BASE = "playlist"
    const val POST_COMPOSER = "post_composer"
    const val ARTICLE_EDITOR = "article_editor"
    const val ARTICLE_EDITOR_BASE = "article_editor"
    const val SITE_PAGE = "site_page/{slug}"
    const val SITE_PAGE_BASE = "site_page"
    const val CONVERSATIONS = "conversations"
    const val CONVERSATION_DETAIL = "conversation/{conversationId}/{username}"
    const val CONVERSATION_DETAIL_BASE = "conversation"

    // ── Phase 0 stabilization: removed dead route constants ──────────
    // The following were declared but never wired into the NavHost AND
    // had no callers (verified via grep before removal):
    //   const val COMMENTS = "comments/{postId}"
    //   const val COMMENTS_BASE = "comments"
    //   const val ARTICLE_EDITOR_EDIT = "article_editor/{id}"
    //   fun comments(postId: String) = ...
    //   fun articleEditorEdit(id: String) = ...
    // Comments are surfaced inside PostDetailScreen's bottom bar (no
    // separate route needed). Article-editor-edit will be wired when
    // Phase 1 (Article parity) builds the real ArticleEditor screen.

    fun postDetail(postId: String) = "$POST_DETAIL_BASE/$postId"
    fun articleDetail(articleId: String) = "$ARTICLE_DETAIL_BASE/$articleId"
    fun userProfile(username: String) = "$USER_PROFILE_BASE/$username"
    fun followers(username: String) = "$FOLLOWERS_BASE/$username"
    fun following(username: String) = "$FOLLOWING_BASE/$username"
    fun resetPassword(token: String) = "$RESET_PASSWORD_BASE?token=$token"
    fun topicDetail(slug: String) = "$TOPIC_DETAIL_BASE/$slug"
    fun collectionDetail(id: String) = "$COLLECTION_DETAIL_BASE/$id"
    fun playlistDetail(id: String) = "$PLAYLIST_DETAIL_BASE/$id"
    fun sitePage(slug: String) = "$SITE_PAGE_BASE/$slug"
    fun conversationDetail(conversationId: String, username: String) =
        "$CONVERSATION_DETAIL_BASE/$conversationId/$username"
}

/**
 * The bottom-nav destinations.
 *
 * NOTE: The `ADMIN` destination has been REMOVED in Round 3 of the
 * deep-debugging work — the user requested no admin UI in the Android
 * app. Admin users now see the same 5 bottom-nav items as regular users
 * (Home, Search, Notifications, Profile, Messages). The backend's
 * admin endpoints remain available for the website admin dashboard;
 * they're just not surfaced in the Android app anymore.
 */
enum class BottomNavDestination(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
    /** If true, this destination is only rendered when the user has admin role.
     *  Currently unused (no admin destinations in the Android app) but kept
     *  for future extensibility. */
    val adminOnly: Boolean = false,
) {
    HOME(
        route = Routes.HOME,
        labelRes = com.centrychat.android.R.string.nav_home,
        icon = Icons.Filled.Home,
        selectedIcon = Icons.Filled.Home,
    ),
    SEARCH(
        route = Routes.SEARCH,
        labelRes = com.centrychat.android.R.string.nav_search,
        icon = Icons.Filled.Search,
        selectedIcon = Icons.Filled.Search,
    ),
    NOTIFICATIONS(
        route = Routes.NOTIFICATIONS,
        labelRes = com.centrychat.android.R.string.nav_notifications,
        icon = Icons.Filled.Notifications,
        selectedIcon = Icons.Filled.Notifications,
    ),
    // ── UI POSITION SWAP (per user request) ──────────────────────────────
    // The user asked to swap the visual positions of Profile and Messages
    // in the bottom-nav. Previously the order was:
    //   HOME, SEARCH, NOTIFICATIONS, PROFILE, MESSAGES
    // Now it is:
    //   HOME, SEARCH, NOTIFICATIONS, MESSAGES, PROFILE
    //
    // CRITICAL: only the enum ORDER changed (which determines the visual
    // position in the bottom-nav). The `route` values, label resources,
    // icons, click handlers, and navigation logic are UNCHANGED — tapping
    // "Messages" still navigates to Routes.CONVERSATIONS (the
    // ConversationsScreen), tapping "Profile" still navigates to
    // Routes.PROFILE (the ProfileScreen). No routes, no view-models, no
    // backend calls were touched.
    MESSAGES(
        route = Routes.CONVERSATIONS,
        labelRes = com.centrychat.android.R.string.nav_messages,
        icon = Icons.Filled.Email,
        selectedIcon = Icons.Filled.Email,
    ),
    PROFILE(
        route = Routes.PROFILE,
        labelRes = com.centrychat.android.R.string.nav_profile,
        icon = Icons.Filled.Person,
        selectedIcon = Icons.Filled.Person,
    ),
}
