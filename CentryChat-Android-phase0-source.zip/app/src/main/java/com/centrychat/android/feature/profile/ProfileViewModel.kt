package com.centrychat.android.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.ProfileDetailDto
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.repository.ArticlesRepository
import com.centrychat.android.data.repository.PlaylistsRepository
import com.centrychat.android.data.repository.PostsRepository
import com.centrychat.android.data.repository.ProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The active tab on the Profile screen — mirrors the web's profile tab
 * layout.
 *
 * The web's Profile (src/components/profile/profile-screen.tsx) exposes
 * only TWO tabs:
 *   - Posts     → renders Posts (short posts) FIRST, then Articles
 *                (long-form posts) below them, in a single "divide-y"
 *                list (NOT a sub-tab). An Article is treated as a kind
 *                of content inside the Posts tab, not as a separate
 *                section.
 *   - Playlists → renders the user's playlists (public + own private).
 *
 * The Android app now mirrors this layout exactly. The previous version
 * had THREE tabs (Posts | Articles | Playlists); the Articles tab has
 * been removed and Articles are now merged into the Posts tab list.
 */
enum class ProfileTab(val labelRes: Int) {
    POSTS(com.centrychat.android.R.string.profile_posts),
    PLAYLISTS(com.centrychat.android.R.string.profile_playlists),
}

/**
 * Follow-button state machine — mirrors the web's FollowButton states.
 *
 * The web's `FollowButton` (src/components/shared/follow-button.tsx) has
 * 4 visual states derived from the (isFollowing, isFollowedBy) pair:
 *
 *   isFollowing=false, isFollowedBy=false  → "Follow"           (primary action)
 *   isFollowing=false, isFollowedBy=true   → "Follow Back"      (primary action)
 *   isFollowing=true, isFollowedBy=false   → "Following"        (outline button)
 *   isFollowing=true, isFollowedBy=true    → "Following"        (outline button)
 */
enum class FollowButtonState(val labelRes: Int) {
    FOLLOW(com.centrychat.android.R.string.follow_state_follow),
    FOLLOW_BACK(com.centrychat.android.R.string.follow_state_follow_back),
    FOLLOWING(com.centrychat.android.R.string.follow_state_following);

    companion object {
        fun from(following: Boolean, followedBy: Boolean): FollowButtonState = when {
            following -> FOLLOWING
            followedBy -> FOLLOW_BACK
            else -> FOLLOW
        }
    }
}

/**
 * A unified feed row for the Posts tab — either a short Post or a long
 * Article. Mirrors the web's Profile "Posts" tab layout (a single
 * divide-y list of PostCard + ArticleCard rows).
 *
 * The web renders Posts first, then Articles (see
 * src/components/profile/profile-screen.tsx lines 904-925). The Android
 * client now preserves that order: `feedItems` returns Posts first,
 * then Articles.
 *
 * The `kind` field lets the UI render the right card layout (Post card
 * vs Article card) without needing `when` branches on null-checks.
 */
sealed class ProfileFeedItem {
    abstract val id: String

    data class Post(val post: PostDto) : ProfileFeedItem() {
        override val id: String get() = post.id
    }

    data class Article(val article: ArticleCardDto) : ProfileFeedItem() {
        override val id: String get() = article.id
    }
}

class ProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository
    private val postsRepo: PostsRepository = appContainer.postsRepository
    private val articlesRepo: ArticlesRepository = appContainer.articlesRepository
    private val playlistsRepo: PlaylistsRepository = appContainer.playlistsRepository

    private val _profileState = MutableStateFlow<UiState<UserProfileSummary>>(UiState.Loading)
    val profileState: StateFlow<UiState<UserProfileSummary>> = _profileState.asStateFlow()

    private val _isFollowing = MutableStateFlow(false)
    val isFollowing: StateFlow<Boolean> = _isFollowing.asStateFlow()

    private val _isFollowedBy = MutableStateFlow(false)
    val isFollowedBy: StateFlow<Boolean> = _isFollowedBy.asStateFlow()

    private val _selectedTab = MutableStateFlow(ProfileTab.POSTS)
    val selectedTab: StateFlow<ProfileTab> = _selectedTab.asStateFlow()

    /**
     * The unified Posts-tab feed — Posts first, then Articles.
     *
     * This single StateFlow replaces the previous separate `_posts` +
     * `_articles` flows. The web's Profile renders the Posts tab as ONE
     * list (posts then articles), so the Android client now models it
     * the same way: one feed with mixed kinds, renderable with a single
     * LazyColumn.
     */
    private val _feed = MutableStateFlow<UiState<List<ProfileFeedItem>>>(UiState.Loading)
    val feed: StateFlow<UiState<List<ProfileFeedItem>>> = _feed.asStateFlow()

    private val _playlists = MutableStateFlow<UiState<List<PlaylistDto>>>(UiState.Loading)
    val playlists: StateFlow<UiState<List<PlaylistDto>>> = _playlists.asStateFlow()

    /** Most-recently-loaded username — used by [refresh] to re-fetch the
     *  same profile's content without requiring the caller to pass it
     *  again. Null when no profile has been loaded yet. */
    private var lastUsername: String? = null
    private var lastAuthorId: String? = null

    fun loadProfile(username: String?) {
        _profileState.value = UiState.Loading
        // Reset all tab states so a new profile doesn't briefly show the
        // previous user's posts/articles/playlists while loading.
        _feed.value = UiState.Loading
        _playlists.value = UiState.Loading
        viewModelScope.launch {
            try {
                if (username.isNullOrBlank()) {
                    // Load the current user's own profile.
                    val me = repo.getMyProfile().user
                    if (me == null) {
                        _profileState.value = UiState.Empty
                        return@launch
                    }
                    val profile = UserProfileSummary(
                        id = me.id,
                        fullName = me.fullName,
                        username = me.username,
                        avatarColor = me.avatarColor,
                        avatarUrl = me.avatarUrl,
                        isVerified = me.isVerified,
                        bio = me.bio,
                        followersCount = 0,
                        followingCount = 0,
                        postsCount = 0,
                        isFollowing = false,
                        isFollowedBy = false,
                    )
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = false
                    _isFollowedBy.value = false
                    lastUsername = me.username
                    lastAuthorId = me.id
                    loadUserContent(me.username, me.id)
                } else {
                    val profile = repo.getPublicProfile(username)
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = profile.isFollowing
                    _isFollowedBy.value = profile.isFollowedBy
                    lastUsername = username
                    lastAuthorId = profile.id
                    loadUserContent(username, profile.id)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _profileState.value = UiState.Error(e.message ?: "Could not load profile.")
            }
        }
    }

    /**
     * Load the profile's Posts-tab feed (Posts + Articles merged) +
     * Playlists tab in parallel.
     *
     * CONTRACT:
     *  - **Posts tab**: fetches BOTH the user's Posts (`GET /api/v1/posts?
     *    authorId={authorId}`) AND the user's Articles (`GET /api/v1/
     *    users/{username}/articles?limit=50`), then merges them into a
     *    single list. The web renders Posts first then Articles in one
     *    `divide-y` list (see src/components/profile/profile-screen.tsx
     *    lines 904-925); the Android client mirrors that order:
     *    `posts + articles`.
     *
     *    The two fetches run in PARALLEL (separate coroutines) but the
     *    merged feed only emits once BOTH complete — this is done by
     *    waiting on both `Deferred`s in a single coroutine, then
     *    publishing the merged list.
     *
     *  - **Playlists tab**: uses `GET /api/v1/users/{username}/playlists`
     *    (public-friendly — owner sees all, others see public-only).
     */
    private fun loadUserContent(username: String, authorId: String) {
        viewModelScope.launch {
            try {
                // Fetch posts + articles in parallel inside one coroutine,
                // then merge them. Posts come first (web's order), then
                // articles. Empty lists are fine — the UI's empty-state
                // only triggers when BOTH are empty.
                val postsDeferred = async {
                    postsRepo.getPosts(authorId = authorId, limit = 50).posts
                }
                val articlesDeferred = async {
                    articlesRepo.getUserArticles(username, limit = 50)
                }
                val posts = postsDeferred.await()
                val articles = articlesDeferred.await()
                val feed = buildList {
                    posts.forEach { add(ProfileFeedItem.Post(it)) }
                    articles.forEach { add(ProfileFeedItem.Article(it)) }
                }
                _feed.value = if (feed.isEmpty()) UiState.Empty else UiState.Success(feed)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _feed.value = UiState.Error(e.message ?: "Could not load posts.")
            }
        }
        viewModelScope.launch {
            try {
                val playlists = playlistsRepo.getUserPlaylists(username, limit = 100).playlists
                _playlists.value = if (playlists.isEmpty()) UiState.Empty else UiState.Success(playlists)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _playlists.value = UiState.Error(e.message ?: "Could not load playlists.")
            }
        }
    }

    /** Re-fetch the profile's content for the most recently loaded user.
     *  Used by the pull-to-refresh gesture on the Profile screen. */
    fun refresh() {
        val u = lastUsername
        val a = lastAuthorId
        if (u != null && a != null) {
            loadUserContent(u, a)
        }
    }

    fun selectTab(tab: ProfileTab) {
        _selectedTab.value = tab
    }

    fun toggleFollow(username: String) {
        viewModelScope.launch {
            try {
                if (_isFollowing.value) {
                    repo.unfollow(username)
                    _isFollowing.value = false
                } else {
                    repo.follow(username)
                    _isFollowing.value = true
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }
}

class EditProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository

    private val _profile = MutableStateFlow<ProfileDetailDto?>(null)
    val profile: StateFlow<ProfileDetailDto?> = _profile.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveError = MutableStateFlow<String?>(null)
    val saveError: StateFlow<String?> = _saveError.asStateFlow()

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    fun load() {
        viewModelScope.launch {
            try {
                val me = repo.getMyProfile().user
                _profile.value = me
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun save(
        fullName: String,
        username: String,
        bio: String?,
        avatarUrl: String?,
        language: String,
        gender: String?,
        dateOfBirth: String?,
        countryCode: String?,
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            _saveError.value = null
            try {
                val changes = buildMap {
                    put("fullName", fullName)
                    put("username", username)
                    put("bio", bio)
                    put("avatarUrl", avatarUrl)
                    put("language", language)
                    if (gender != null) put("gender", gender)
                    if (dateOfBirth != null) put("dateOfBirth", dateOfBirth)
                    if (countryCode != null) put("countryCode", countryCode)
                }
                val updated = repo.updateMyProfile(changes)
                _profile.value = updated.user
                _saved.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _saveError.value = e.message ?: "Could not save profile."
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun consumeSaved() {
        _saved.value = false
    }
}
