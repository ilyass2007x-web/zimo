package com.centrychat.android.core.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.centrychat.android.data.repository.SettingsRepository
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember

// ── Color schemes ─────────────────────────────────────────────────────────
//
// WEBSITE PARITY — these colors mirror the OKLCH tokens defined in the
// website's `src/app/globals.css` (light theme) + `.dark` (dark theme).
// The website uses Tailwind tokens mapped from CSS variables; we map
// the same hex values to Material 3 color roles so Compose components
// match the website's visual identity (near-black primary instead of
// the original Material blue, neutral gray borders, etc.).
//
// Light theme tokens (from `globals.css :root`):
//   --background    oklch(1 0 0)       → #FFFFFF
//   --foreground    oklch(0.145 0 0)  → #0A0A0A (near-black)
//   --card          oklch(1 0 0)       → #FFFFFF
//   --primary       oklch(0.205 0 0)  → #111111 (near-black)
//   --secondary     oklch(0.97 0 0)   → #F5F5F5
//   --muted-foreground oklch(0.556 0 0) → #737373 (gray-500)
//   --accent        oklch(0.97 0 0)   → #F5F5F5
//   --destructive   oklch(0.577 0.245 27.325) → #E11D48 (red-600)
//   --border        oklch(0.922 0 0)  → #E5E5E5 (neutral-200)

private val LightColors = lightColorScheme(
    // Primary — near-black (matches website --primary oklch(0.205 0 0) ≈ #111111).
    // Used for active tab indicators, link color, default button bg.
    primary = Color(0xFF111111),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = Color(0xFF111111),
    // Secondary — light gray (matches website --secondary oklch(0.97 0 0) ≈ #F5F5F5).
    secondary = Color(0xFFF5F5F5),
    onSecondary = Color(0xFF111111),
    secondaryContainer = Color(0xFFE5E5E5),
    onSecondaryContainer = Color(0xFF111111),
    // Tertiary — kept for brand accent (verified badge blue, etc.).
    tertiary = Color(0xFF2563EB), // blue-600 (website uses blue-500 #3B82F6 for verified)
    onTertiary = Color.White,
    // Background — pure white (matches website --background).
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF0A0A0A),
    // Surface — pure white for cards (matches website --card).
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0A0A0A),
    surfaceVariant = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFF737373), // muted-foreground (gray-500)
    surfaceTint = Color(0xFF111111),
    inverseSurface = Color(0xFF0A0A0A),
    inverseOnSurface = Color(0xFFFAFAFA),
    // Outline — neutral-200 (matches website --border).
    outline = Color(0xFFE5E5E5),
    outlineVariant = Color(0xFFF5F5F5),
    // Error — red-600 (matches website --destructive ≈ #E11D48).
    error = Color(0xFFE11D48),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
)

private val DarkColors = darkColorScheme(
    // Primary — near-white on dark (website .dark --primary oklch(0.985 0 0) ≈ #FAFAFA).
    primary = Color(0xFFFAFAFA),
    onPrimary = Color(0xFF0A0A0A),
    primaryContainer = Color(0xFF171717),
    onPrimaryContainer = Color(0xFFFAFAFA),
    // Secondary — neutral-900 (website .dark --secondary oklch(0.205 0 0) ≈ #171717).
    secondary = Color(0xFF171717),
    onSecondary = Color(0xFFFAFAFA),
    secondaryContainer = Color(0xFF262626),
    onSecondaryContainer = Color(0xFFFAFAFA),
    // Tertiary — blue-500 (matches website verified badge color in dark).
    tertiary = Color(0xFF3B82F6),
    onTertiary = Color.White,
    // Background — near-black (website .dark --background oklch(0.145 0 0) ≈ #0A0A0A).
    background = Color(0xFF0A0A0A),
    onBackground = Color(0xFFFAFAFA),
    surface = Color(0xFF0A0A0A),
    onSurface = Color(0xFFFAFAFA),
    surfaceVariant = Color(0xFF171717),
    onSurfaceVariant = Color(0xFFA3A3A3), // neutral-400
    surfaceTint = Color(0xFFFAFAFA),
    inverseSurface = Color(0xFFFAFAFA),
    inverseOnSurface = Color(0xFF0A0A0A),
    outline = Color(0xFF262626), // neutral-800
    outlineVariant = Color(0xFF171717),
    error = Color(0xFFF43F5E),
    onError = Color(0xFF0A0A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2),
)

// ── Typography ────────────────────────────────────────────────────────────

private val AppTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 40.sp, letterSpacing = (-0.25).sp),
    displayMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 36.sp),
    displaySmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 32.sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 20.sp, lineHeight = 26.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 24.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.15.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.5.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.25.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp),
)

/** Local provider for the app's brand color (the accent used for the verified
 *  badge, the "follow" button highlight, etc.). Resolved from the current
 *  ColorScheme so it adapts to dark mode automatically. */
private val LocalBrandAccent = staticCompositionLocalOf { Color(0xFF3B82F6) } // blue-500

/**
 * The root theme composable.
 *
 * Pulls the user's dark-mode preference from the [SettingsRepository] and
 * applies the matching Material 3 color scheme. When the preference is "follow
 * system" (the default), uses the platform dark-mode setting.
 */
@Composable
fun CentryChatTheme(
    darkModeOverride: Int? = null,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val settingsRepository = remember { SettingsRepository(context) }
    val savedDarkMode by settingsRepository.darkModeFlow.collectAsState(initial = 0)

    val resolvedDarkMode = darkModeOverride ?: savedDarkMode
    val isDark = when (resolvedDarkMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    val colorScheme = if (isDark) DarkColors else LightColors

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !isDark
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !isDark
        }
    }

    CompositionLocalProvider(
        LocalBrandAccent provides colorScheme.secondary,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content,
        )
    }
}

/** Returns the brand accent color for the current theme. */
object CentryChatColors {
    val brandAccent: Color
        @Composable get() = LocalBrandAccent.current
}
