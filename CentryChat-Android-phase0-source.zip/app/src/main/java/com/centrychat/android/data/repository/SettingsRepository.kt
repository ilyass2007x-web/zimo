package com.centrychat.android.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * App-level settings repository.
 *
 * Stores the user's UI preferences (dark mode setting, language) in
 * (non-encrypted) DataStore. These are NOT secrets — they're just UI state.
 *
 * The dark-mode setting uses an Int to allow a three-way choice:
 *   0 = follow system (default)
 *   1 = always dark
 *   2 = always light
 */
private val Context.appSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "centrychat_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DARK_MODE = intPreferencesKey("dark_mode")
        val LANGUAGE = stringPreferencesKey("language")
    }

    val darkModeFlow: Flow<Int> = context.appSettingsDataStore.data.map { it[Keys.DARK_MODE] ?: 0 }
    val languageFlow: Flow<String> = context.appSettingsDataStore.data.map { it[Keys.LANGUAGE] ?: "en" }

    suspend fun setDarkMode(value: Int) {
        context.appSettingsDataStore.edit { it[Keys.DARK_MODE] = value }
    }

    suspend fun setLanguage(value: String) {
        context.appSettingsDataStore.edit { it[Keys.LANGUAGE] = value }
    }
}
