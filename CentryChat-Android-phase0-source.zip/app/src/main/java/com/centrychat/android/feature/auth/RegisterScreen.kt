package com.centrychat.android.feature.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.rememberAuthViewModel

/**
 * The signup screen.
 *
 * Collects all fields required by the backend's `/api/v1/auth/register` route:
 * fullName, email, username, password, gender, countryCode, dateOfBirth (optional).
 *
 * On success, the backend auto-logs the user in (no email-verification gate) and
 * calls [onRegistered] (which navigates to the home feed).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(
    onRegistered: () -> Unit,
    onLoginClick: () -> Unit,
) {
    val viewModel = rememberAuthViewModel()
    val state by viewModel.registerState.collectAsStateWithLifecycle()

    LaunchedEffect(state.successEvent) {
        if (state.successEvent) {
            viewModel.consumeRegisterSuccess()
            onRegistered()
        }
    }

    var showPassword by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.auth_register_title)) },
                navigationIcon = {
                    IconButton(onClick = onLoginClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.auth_register_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            OutlinedTextField(
                value = state.fullName,
                onValueChange = { viewModel.onRegisterFieldChange(fullName = it) },
                label = { Text(stringResource(R.string.auth_field_full_name)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = state.email,
                onValueChange = { viewModel.onRegisterFieldChange(email = it) },
                label = { Text(stringResource(R.string.auth_field_email)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = state.username,
                onValueChange = { viewModel.onRegisterFieldChange(username = it) },
                label = { Text(stringResource(R.string.auth_field_username)) },
                singleLine = true,
                prefix = { Text("@") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = state.password,
                onValueChange = { viewModel.onRegisterFieldChange(password = it) },
                label = { Text(stringResource(R.string.auth_field_password)) },
                singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showPassword = !showPassword }) {
                        Icon(
                            imageVector = if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = null,
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = state.confirmPassword,
                onValueChange = { viewModel.onRegisterFieldChange(confirmPassword = it) },
                label = { Text(stringResource(R.string.auth_field_confirm_password)) },
                singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Next,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            // Gender (required by the backend for video-chat matchmaking)
            GenderSelector(
                selected = state.gender,
                onChange = { viewModel.onRegisterFieldChange(gender = it) },
            )

            // Country (required)
            CountrySelector(
                selected = state.countryCode,
                onChange = { viewModel.onRegisterFieldChange(countryCode = it) },
            )

            // Date of birth (optional — pass empty string for "not provided")
            OutlinedTextField(
                value = state.dateOfBirth,
                onValueChange = { viewModel.onRegisterFieldChange(dateOfBirth = it) },
                label = { Text(stringResource(R.string.auth_field_date_of_birth)) },
                placeholder = { Text("YYYY-MM-DD") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Done,
                ),
                modifier = Modifier.fillMaxWidth(),
            )

            state.errorMessage?.let { msg ->
                Text(
                    text = msg,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Button(
                onClick = viewModel::register,
                enabled = !state.isLoading,
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp),
                    )
                } else {
                    Text(stringResource(R.string.auth_action_register))
                }
            }

            TextButton(onClick = onLoginClick, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.auth_action_have_account))
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun GenderSelector(
    selected: String,
    onChange: (String) -> Unit,
) {
    val options = listOf("MALE" to "Male", "FEMALE" to "Female", "PREFER_NOT_TO_SAY" to "Prefer not to say")
    Column {
        Text(
            text = stringResource(R.string.auth_field_gender),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { (value, label) ->
                androidx.compose.material3.FilterChip(
                    selected = selected == value,
                    onClick = { onChange(value) },
                    label = { Text(label) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun CountrySelector(
    selected: String,
    onChange: (String) -> Unit,
) {
    val countries = listOf(
        "MA" to "Morocco",
        "US" to "United States",
        "FR" to "France",
        "ES" to "Spain",
        "DE" to "Germany",
        "GB" to "United Kingdom",
        "SA" to "Saudi Arabia",
        "AE" to "United Arab Emirates",
        "EG" to "Egypt",
        "DZ" to "Algeria",
        "TN" to "Tunisia",
        "LY" to "Libya",
        "JO" to "Jordan",
        "PS" to "Palestine",
        "LB" to "Lebanon",
        "IQ" to "Iraq",
        "SY" to "Syria",
        "KW" to "Kuwait",
        "QA" to "Qatar",
        "BH" to "Bahrain",
        "OM" to "Oman",
        "YE" to "Yemen",
        "TR" to "Turkey",
        "IR" to "Iran",
        "CA" to "Canada",
        "AU" to "Australia",
        "IT" to "Italy",
        "NL" to "Netherlands",
        "BE" to "Belgium",
        "CH" to "Switzerland",
        "PT" to "Portugal",
        "BR" to "Brazil",
        "MX" to "Mexico",
        "AR" to "Argentina",
        "IN" to "India",
        "PK" to "Pakistan",
        "ID" to "Indonesia",
        "MY" to "Malaysia",
        "SG" to "Singapore",
        "JP" to "Japan",
        "KR" to "South Korea",
        "CN" to "China",
        "RU" to "Russia",
        "UA" to "Ukraine",
        "PL" to "Poland",
        "SE" to "Sweden",
        "NO" to "Norway",
        "DK" to "Denmark",
        "FI" to "Finland",
        "IE" to "Ireland",
        "AT" to "Austria",
        "CZ" to "Czech Republic",
        "GR" to "Greece",
        "RO" to "Romania",
        "HU" to "Hungary",
        "BG" to "Bulgaria",
        "HR" to "Croatia",
        "SK" to "Slovakia",
        "SI" to "Slovenia",
        "LT" to "Lithuania",
        "LV" to "Latvia",
        "EE" to "Estonia",
    )
    var expanded by remember { mutableStateOf(false) }
    val selectedLabel = countries.firstOrNull { it.first == selected }?.second ?: ""

    Column {
        Text(
            text = stringResource(R.string.auth_field_country),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(4.dp))
        Box {
            OutlinedTextField(
                value = selectedLabel,
                onValueChange = { },
                readOnly = true,
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Select your country") },
                trailingIcon = {
                    IconButton(onClick = { expanded = !expanded }) {
                        Icon(
                            imageVector = if (expanded) androidx.compose.material.icons.Icons.Filled.ArrowDropUp
                            else androidx.compose.material.icons.Icons.Filled.ArrowDropDown,
                            contentDescription = null,
                        )
                    }
                },
            )
            androidx.compose.material3.DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
            ) {
                countries.forEach { (code, label) ->
                    androidx.compose.material3.DropdownMenuItem(
                        text = { Text(label) },
                        onClick = {
                            onChange(code)
                            expanded = false
                        },
                    )
                }
            }
        }
    }
}
