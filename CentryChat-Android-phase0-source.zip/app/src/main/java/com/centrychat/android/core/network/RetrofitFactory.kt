package com.centrychat.android.core.network

import com.centrychat.android.BuildConfig
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit

/**
 * Builds the [Retrofit] instance bound to the CentryChat backend.
 *
 * The base URL is configured at build time via [BuildConfig.API_BASE_URL]
 * (see app/build.gradle.kts). The default points to the production Netlify
 * deployment. Override it for staging by editing the build.gradle.kts
 * `buildConfigField` line in the relevant build type.
 *
 * WHY NOT USE A RUNTIME BASE URL?
 *  - The backend has a single fixed URL (centrychat.netlify.app). Building
 *    it in keeps the production secret surface small + prevents accidental
 *    configuration drift (e.g. someone setting a wrong URL in a release).
 *  - For local development, set `centrychat.apiBaseUrl=http://10.0.2.2:3000`
 *    in gradle.properties when building a debug APK — the build system
 *    injects it into BuildConfig.API_BASE_URL.
 */
object RetrofitFactory {

    /** The JSON parser — configured to be lenient enough to handle the
     *  backend's various response shapes (some endpoints return null for
     *  optional fields, others return empty arrays). */
    val json: Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    fun create(client: OkHttpClient): Retrofit {
        val contentType = "application/json".toMediaType()
        return Retrofit.Builder()
            .baseUrl(ensureTrailingSlash(BuildConfig.API_BASE_URL))
            .client(client)
            .addConverterFactory(json.asConverterFactory(contentType))
            .build()
    }

    private fun ensureTrailingSlash(url: String): String =
        if (url.endsWith("/")) url else "$url/"
}
