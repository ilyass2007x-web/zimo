package com.centrychat.android.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * A reusable "profile identity row" — avatar + full name (with optional
 * verified badge) + @username.
 *
 * Renders the user identity in a CONSISTENT layout across the whole app:
 *
 *   [Avatar] Full Name ✓
 *            @username
 *
 * Used by:
 *   - FeedScreen's PostCard + ArticleCard (author row)
 *   - PostDetailScreen + ArticleDetailScreen (author row)
 *   - ProfileScreen (header)
 *   - SearchScreen (user result row)
 *   - NotificationsScreen (sender row)
 *   - MessagesScreen (conversation list + thread header)
 *
 * Why a single component: ensures that whenever the design changes
 * (e.g. avatar size, badge position, typography), all screens update
 * in lockstep — no drift between Feed / Profile / Search / etc.
 *
 * The verified badge rendered here is the SHARED `VerifiedBadge` from
 * `Avatar.kt` — the same component used by FeedScreen, PostDetailScreen,
 * ProfileScreen, etc. — so the badge looks identical everywhere a user
 * identity appears (no per-screen drift).
 *
 * @param fullName   The user's full name (e.g. "Test User").
 * @param username   The user's @handle (without the @).
 * @param avatarColor  Hex color string for the fallback avatar.
 * @param avatarUrl    Optional uploaded avatar URL.
 * @param isVerified   Whether the user has the blue badge (server-granted).
 * @param onClick      Optional click handler (typically navigates to profile).
 * @param avatarSize   Avatar diameter (defaults to 40.dp; smaller for
 *                     compact contexts like comments).
 * @param nameStyle    Optional override for the full-name typography.
 * @param compact      If true, hides the @username line (used in tight
 *                     spaces like notification rows).
 */
@Composable
fun ProfileIdentityRow(
    fullName: String,
    username: String,
    avatarColor: String?,
    avatarUrl: String?,
    isVerified: Boolean,
    onClick: (() -> Unit)? = null,
    avatarSize: Dp = 40.dp,
    nameStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    compact: Boolean = false,
    showUsername: Boolean = true,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier,
    ) {
        CentryChatAvatar(
            fullName = fullName,
            avatarColor = avatarColor,
            avatarUrl = avatarUrl,
            onClick = onClick,
            size = avatarSize,
        )
        Spacer(Modifier.width(4.dp))
        Column(
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = fullName,
                    style = nameStyle,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                if (isVerified) {
                    VerifiedBadge(size = avatarSize * 0.4f)
                }
            }
            if (showUsername && !compact && username.isNotBlank()) {
                Text(
                    text = "@$username",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                )
            }
        }
    }
}
