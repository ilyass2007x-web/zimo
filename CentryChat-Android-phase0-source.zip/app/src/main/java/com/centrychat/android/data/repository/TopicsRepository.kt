package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.FeedResponse
import com.centrychat.android.data.model.TopicDetailResponse
import com.centrychat.android.data.model.TopicDto
import com.centrychat.android.data.model.TopicsListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Topics repository — wraps `/api/v1/topics/[endpoint]`.
 *
 * Two-tier system (mirrors the web):
 *  1. **ContentTopic** — curated topics with slug, name, description, isActive.
 *     CRUD via admin. ArticleTopic + PostTopic join tables link content.
 *  2. **Hashtag fallback** — when no ContentTopic matches the slug, the
 *     `/topics/{slug}/content` endpoint falls back to searching content
 *     containing `#tag` (case-insensitive).
 *
 * Users can follow topics — followed topics boost content in the
 * personalized feed.
 */
class TopicsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** List all active ContentTopics. */
    suspend fun getTopics(limit: Int = 50): TopicsListResponse =
        safeApiCall { api.getTopics(limit = limit) }

    /** Get a single topic by slug. */
    suspend fun getTopic(slug: String): TopicDetailResponse =
        safeApiCall { api.getTopic(slug) }

    /** Fetch posts + articles for a topic (paginated, cursor-based). */
    suspend fun getTopicContent(
        slug: String,
        cursor: String? = null,
        limit: Int = 20,
    ): FeedResponse =
        safeApiCall { api.getTopicContent(slug = slug, limit = limit, cursor = cursor) }

    /** Follow a topic — boosts its content in the personalized feed. */
    suspend fun follow(slug: String): Boolean {
        safeApiCall { api.followTopic(slug = slug, origin = origin) }
        return true
    }

    /** Unfollow a topic. */
    suspend fun unfollow(slug: String): Boolean {
        safeApiCall { api.unfollowTopic(slug = slug, origin = origin) }
        return true
    }
}
