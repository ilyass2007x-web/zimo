package com.centrychat.android.ui.components

/**
 * Local URL classifier — mirrors the website's `parseYouTube` and `parseVimeo`
 * functions (src/lib/media/embeds.ts) + URL-extension inference
 * (src/lib/media/resolver.ts → inferMediaTypeFromUrl).
 *
 * WHY THIS EXISTS:
 *  - The previous UnifiedVideoPlayer ALWAYS called POST /api/v1/media/resolve
 *    for every URL, even for YouTube watch URLs that we can classify locally
 *    without a network round-trip.
 *  - The resolver's response for YouTube/Vimeo is `type=embed` + an
 *    `embedUrl` like `https://www.youtube-nocookie.com/embed/<id>` — but the
 *    previous WebView loaded that embedUrl INSIDE an HTML iframe via
 *    `loadDataWithBaseURL`, which causes YouTube/Vimeo to render a blank/
 *    black iframe (cross-origin iframe inside a data-URI-base page).
 *  - Classifying locally lets us build the correct embed URL ourselves and
 *    load it DIRECTLY in the WebView (the WebView BECOMES the iframe),
 *    which is how the YouTube IFrame API + Vimeo Player API are designed
 *    to be embedded in apps.
 *  - For direct MP4/HLS/DASH, we skip the resolver call entirely and hand
 *    the URL straight to ExoPlayer — saves 200–500ms of latency + a
 *    network call that can fail.
 *
 * MIRRORED REGEXES (kept byte-identical to the website source):
 *  - YouTube:  youtu.be/<11-char-id>  |  youtube.com/(embed|shorts)/<id>  |  [?&]v=<id>
 *  - Vimeo:     vimeo.com/(video/|channels/<name>/)?<numeric-id>
 *  - Direct video extensions:  .mp4 .webm .mov .m4v .ogg .ogv .m3u8 .ts .mpd
 *
 * No network calls — pure regex on the URL string. Safe to call on the main
 * thread. Returns [VideoKind.Unknown] when no pattern matches, so the caller
 * can fall back to the resolver.
 */
object VideoUrlClassifier {

    /** 11-character YouTube video ID (matches the website's `[A-Za-z0-9_-]{11}`). */
    private val YOUTUBE_ID = Regex("""[A-Za-z0-9_-]{11}""")

    /** Numeric Vimeo video ID. */
    private val VIMEO_ID = Regex("""\d+""")

    /** Direct video file extensions — mirrors the website's
     *  `inferMediaTypeFromUrl` extension list
     *  (src/lib/media/resolver.ts:564-584). */
    private val DIRECT_VIDEO_EXT = setOf(
        "mp4", "m4v", "mov", "webm", "ogg", "ogv", "m3u8", "ts", "mpd",
    )

    /**
     * Classify [url] into one of:
     *  - [VideoKind.YouTube]    → embeddable via `youtube.com/embed/<id>`
     *  - [VideoKind.Vimeo]      → embeddable via `player.vimeo.com/video/<id>`
     *  - [VideoKind.DirectVideo] → playable directly by ExoPlayer
     *  - [VideoKind.Unknown]    → caller should fall back to the resolver
     *
     * The function is pure — no IO, no side effects. Safe to call on the
     * main thread. Returns [VideoKind.Unknown] when [url] is null/blank or
     * no pattern matches.
     */
    fun classify(url: String?): VideoKind {
        if (url.isNullOrBlank()) return VideoKind.Unknown
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return VideoKind.Unknown

        // Lowercase once for host/extension checks (URLs are case-insensitive
        // for the host + path parts).
        val lower = trimmed.lowercase()

        // ── YouTube ─────────────────────────────────────────────────────
        // Mirrors src/lib/media/embeds.ts → parseYouTube.
        // Accepts: youtu.be/<id>, youtube.com/(embed|shorts)/<id>,
        //          [?&]v=<id>, m.youtube.com, www.youtube.com, youtube-nocookie.com/embed/<id>
        if (lower.contains("youtu.be/") ||
            lower.contains("youtube.com/") ||
            lower.contains("youtube-nocookie.com/")
        ) {
            val id: String? = YOUTUBE_ID.find(trimmed)?.value
            if (id != null && id.length == 11) {
                return VideoKind.YouTube(videoId = id, originalUrl = trimmed)
            }
        }

        // ── Vimeo ──────────────────────────────────────────────────────
        // Mirrors src/lib/media/embeds.ts → parseVimeo.
        // Accepts: vimeo.com/<id>, vimeo.com/video/<id>,
        //          vimeo.com/channels/<name>/<id>, player.vimeo.com/video/<id>
        if (lower.contains("vimeo.com/")) {
            // Strip query string + fragment so the ID regex doesn't pick up
            // digits from `?autoplay=1` or `#t=10`.
            val withoutQuery = trimmed.substringBefore('#').substringBefore('?')
            val match = Regex(
                """vimeo\.com/(?:video/|channels/[^/]+/)?(\d+)"""
            ).find(withoutQuery)
            if (match != null) {
                val id = match.groupValues[1]
                if (id.isNotEmpty()) {
                    return VideoKind.Vimeo(videoId = id, originalUrl = trimmed)
                }
            }
        }

        // ── Direct video by extension ─────────────────────────────────
        // Mirrors src/lib/media/resolver.ts → inferMediaTypeFromUrl.
        // Strips query string + fragment first so `clip.mp4?token=abc` still
        // classifies as DirectVideo.
        val pathPart = trimmed.substringBefore('#').substringBefore('?')
        val ext = pathPart.substringAfterLast('.', missingDelimiterValue = "")
        if (ext.isNotEmpty() && ext.lowercase() in DIRECT_VIDEO_EXT) {
            val mime = mimeForExtension(ext.lowercase())
            return VideoKind.DirectVideo(url = trimmed, mimeHint = mime)
        }

        // ── Fallback: no pattern matched — let the resolver decide ────
        return VideoKind.Unknown
    }

    /** Map a file extension to a Media3 MIME type so ExoPlayer's
     *  DefaultMediaSourceFactory can pick the right extractor upfront. */
    private fun mimeForExtension(ext: String): String? = when (ext) {
        "mp4", "m4v", "mov" -> "video/mp4"
        "webm" -> "video/webm"
        "ogg", "ogv" -> "video/ogg"
        "m3u8" -> "application/vnd.apple.mpegurl"
        "mpd" -> "application/dash+xml"
        "ts" -> "video/mp2t"
        else -> null
    }

    /**
     * Quick filter for "should this URL render a video player widget in a
     * Post card?". Used by FeedScreen / PostDetailScreen to skip non-video
     * URLs (like `https://github.com/...`, `https://example.com/blog/...`)
     * so the user doesn't see a black 16:9 box with "Open original" for
     * links that aren't videos at all.
     *
     * Returns `true` for URLs that classify locally as YouTube, Vimeo, or
     * DirectVideo (i.e. the URL structure itself signals video content).
     * Returns `false` for everything else (the resolver MIGHT still classify
     * it as a video after a Content-Type probe, but we don't want to
     * eagerly render a player widget for every URL in a Post — the
     * website renders plain `<a target="_blank">` for non-video URLs).
     *
     * Safe to call on the main thread. No IO.
     */
    fun isLikelyVideoUrl(url: String?): Boolean {
        // Note: we intentionally don't return `true` for VideoKind.Unknown
        // here. Unknown URLs MAY be videos (the resolver might classify
        // them after a Content-Type probe) — but we don't want to render a
        // black 16:9 box for every link in a Post. Only render when the
        // URL structure itself signals video content.
        return when (classify(url)) {
            is VideoKind.YouTube, is VideoKind.Vimeo, is VideoKind.DirectVideo -> true
            VideoKind.Unknown -> false
        }
    }
}

/**
 * Sealed classification result for a single video URL.
 */
sealed interface VideoKind {
    /** A YouTube watch/embed/shorts/share URL — embeddable via
     *  `https://www.youtube.com/embed/<videoId>`. */
    data class YouTube(val videoId: String, val originalUrl: String) : VideoKind

    /** A Vimeo URL — embeddable via `https://player.vimeo.com/video/<videoId>`. */
    data class Vimeo(val videoId: String, val originalUrl: String) : VideoKind

    /** A direct video file URL (MP4, HLS .m3u8, DASH .mpd, WebM, OGG).
     *  Playable directly by ExoPlayer — no resolver call needed.
     *  [mimeHint] is an optional MIME type inferred from the file extension. */
    data class DirectVideo(val url: String, val mimeHint: String?) : VideoKind

    /** The URL didn't match any local pattern — the caller should fall back
     *  to `POST /api/v1/media/resolve` to learn the playable form. */
    data object Unknown : VideoKind
}
