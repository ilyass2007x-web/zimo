package com.centrychat.android.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.storage.SessionEvent
import com.centrychat.android.core.security.Roles
import com.centrychat.android.feature.articles.ArticlesScreen
import com.centrychat.android.feature.auth.ForgotPasswordScreen
import com.centrychat.android.feature.auth.LoginScreen
import com.centrychat.android.feature.auth.RegisterScreen
import com.centrychat.android.feature.auth.ResetPasswordScreen
import com.centrychat.android.feature.collections.CollectionsScreen
import com.centrychat.android.feature.feed.FeedScreen
import com.centrychat.android.feature.messaging.ConversationDetailScreen
import com.centrychat.android.feature.messaging.ConversationsScreen
import com.centrychat.android.feature.notifications.NotificationsScreen
import com.centrychat.android.feature.playlists.PlaylistsScreen
import com.centrychat.android.feature.post_composer.PostComposerScreen
import com.centrychat.android.feature.post_detail.ArticleDetailScreen
import com.centrychat.android.feature.post_detail.PostDetailScreen
import com.centrychat.android.feature.profile.EditProfileScreen
import com.centrychat.android.feature.profile.ProfileScreen
import com.centrychat.android.feature.search.SearchScreen
import com.centrychat.android.feature.settings.SettingsScreen
import com.centrychat.android.feature.splash.SplashScreen
import com.centrychat.android.feature.topics.TopicsScreen
import kotlinx.coroutines.flow.collectLatest

/**
 * The root Compose entrypoint.
 *
 * Responsibilities:
 *  1. Subscribe to the [SessionEvent] flow + navigate the user back to the
 *     login screen when the backend returns HTTP 401 (expired session).
 *  2. Always start at SPLASH — the splash screen decides whether the user
 *     should land on the login screen or the home feed based on the local
 *     session cookie + a backend verification call.
 *  3. Host the [NavHost] with all routes + the bottom-nav scaffold.
 *
 * CRASH-SAFETY (Root Cause #3 fix):
 *  - The previous version computed `startDestination` based on a
 *    `produceState(hasSession)` whose initial value was `false`. This
 *    meant the app ALWAYS started at LOGIN (the initial value won the
 *    race against the producer coroutine). When `hasSession` later
 *    flipped to `true`, the NavHost's startDestination was already
 *    fixed at LOGIN → the user got stuck on the login screen even
 *    though they had a valid session cookie.
 *  - The fix: ALWAYS start at SPLASH. The splash screen performs a
 *    single async session check + navigates to either HOME (session
 *    alive) or LOGIN (no session / session expired). This is the
 *    standard pattern + eliminates the race condition.
 */
@Composable
fun CentryChatRoot(
    appContainer: AppContainer,
) {
    val navController: NavHostController = rememberNavController()

    // ── React to session expiration ────────────────────────────────────
    LaunchedEffect(appContainer) {
        appContainer.unauthorizedInterceptor.events.collectLatest { event ->
            when (event) {
                SessionEvent.Expired, SessionEvent.LoggedOutRemotely -> {
                    // Pop everything back to the login screen so the user can
                    // re-authenticate. We don't show a toast here — the auth
                    // screen explains what happened.
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
        }
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    NavHost(
        navController = navController,
        // ALWAYS start at SPLASH — this guarantees a single, predictable
        // entrypoint regardless of session state. The splash screen performs
        // the session check + navigates to LOGIN or HOME.
        startDestination = Routes.SPLASH,
    ) {
        // ── Splash ────────────────────────────────────────────────────
        composable(Routes.SPLASH) {
            SplashScreen(
                appContainer = appContainer,
                onSessionAlive = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
                onSessionDead = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
            )
        }

        // ── Auth flow ─────────────────────────────────────────────────
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoggedIn = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onRegisterClick = { navController.navigate(Routes.REGISTER) },
                onForgotPasswordClick = { navController.navigate(Routes.FORGOT_PASSWORD) },
            )
        }
        composable(Routes.REGISTER) {
            RegisterScreen(
                onRegistered = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onLoginClick = { navController.popBackStack() },
            )
        }
        composable(Routes.FORGOT_PASSWORD) {
            ForgotPasswordScreen(
                onBack = { navController.popBackStack() },
                onEmailSent = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.RESET_PASSWORD,
            arguments = listOf(navArgument("token") { type = NavType.StringType }),
        ) { entry ->
            val token = entry.arguments?.getString("token").orEmpty()
            ResetPasswordScreen(
                token = token,
                onPasswordReset = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() },
            )
        }

        // ── Main app (bottom-nav scaffold) ────────────────────────────
        composable(Routes.HOME) {
            MainScaffold(navController = navController, currentRoute = currentRoute, appContainer = appContainer) { padding ->
                FeedScreen(
                    contentPadding = padding,
                    onPostClick = { id -> navController.navigate(Routes.postDetail(id)) },
                    onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                    onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
                )
            }
        }
        composable(Routes.SEARCH) {
            MainScaffold(navController = navController, currentRoute = currentRoute, appContainer = appContainer) { padding ->
                SearchScreen(
                    contentPadding = padding,
                    onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
                    onPostClick = { id -> navController.navigate(Routes.postDetail(id)) },
                    onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                )
            }
        }
        composable(Routes.NOTIFICATIONS) {
            MainScaffold(navController = navController, currentRoute = currentRoute, appContainer = appContainer) { padding ->
                NotificationsScreen(
                    contentPadding = padding,
                    onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
                    onPostClick = { id -> navController.navigate(Routes.postDetail(id)) },
                    onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                )
            }
        }
        composable(Routes.PROFILE) {
            val currentUser by appContainer.authRepository.currentUser.collectAsState()
            MainScaffold(navController = navController, currentRoute = currentRoute, appContainer = appContainer) { padding ->
                ProfileScreen(
                    contentPadding = padding,
                    username = currentUser?.username,
                    isOwnProfile = true,
                    onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                    onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
                    onPostClick = { id -> navController.navigate(Routes.postDetail(id)) },
                    onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                    onPlaylistClick = { id -> navController.navigate(Routes.playlistDetail(id)) },
                    onFollowersClick = { username -> navController.navigate(Routes.followers(username)) },
                    onFollowingClick = { username -> navController.navigate(Routes.following(username)) },
                    onSettingsClick = { navController.navigate(Routes.SETTINGS) },
                    onMessageUser = { userId, username ->
                        // The Profile's "Message" button creates/opens a conversation
                        // with the target user. We navigate directly to the conversations
                        // list for now — the user taps the conversation to open it. A
                        // follow-up improvement would create-or-get the conversation
                        // immediately and navigate to ConversationDetailScreen.
                        navController.navigate(Routes.CONVERSATIONS)
                    },
                )
            }
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onLogout = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                },
            )
        }

        // ── Detail screens ───────────────────────────────────────────
        composable(
            route = Routes.POST_DETAIL,
            arguments = listOf(navArgument("postId") { type = NavType.StringType }),
        ) { entry ->
            val postId = entry.arguments?.getString("postId").orEmpty()
            PostDetailScreen(
                postId = postId,
                onBack = { navController.popBackStack() },
                onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
            )
        }
        composable(
            route = Routes.ARTICLE_DETAIL,
            arguments = listOf(navArgument("articleId") { type = NavType.StringType }),
        ) { entry ->
            val articleId = entry.arguments?.getString("articleId").orEmpty()
            ArticleDetailScreen(
                articleId = articleId,
                onBack = { navController.popBackStack() },
                onUserClick = { username -> navController.navigate(Routes.userProfile(username)) },
            )
        }
        composable(
            route = Routes.USER_PROFILE,
            arguments = listOf(navArgument("username") { type = NavType.StringType }),
        ) { entry ->
            val username = entry.arguments?.getString("username").orEmpty()
            ProfileScreen(
                username = username,
                isOwnProfile = false,
                onBack = { navController.popBackStack() },
                onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                onUserClick = { u -> navController.navigate(Routes.userProfile(u)) },
                onPostClick = { id -> navController.navigate(Routes.postDetail(id)) },
                onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                onPlaylistClick = { id -> navController.navigate(Routes.playlistDetail(id)) },
                onFollowersClick = { u -> navController.navigate(Routes.followers(u)) },
                onFollowingClick = { u -> navController.navigate(Routes.following(u)) },
                onSettingsClick = { navController.navigate(Routes.SETTINGS) },
                onMessageUser = { _, _ -> navController.navigate(Routes.CONVERSATIONS) },
            )
        }
        composable(Routes.EDIT_PROFILE) {
            EditProfileScreen(
                onSaved = { navController.popBackStack() },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.FOLLOWERS,
            arguments = listOf(navArgument("username") { type = NavType.StringType }),
        ) { entry ->
            val username = entry.arguments?.getString("username").orEmpty()
            com.centrychat.android.feature.profile.FollowersScreen(
                username = username,
                isFollowers = true,
                onBack = { navController.popBackStack() },
                onUserClick = { u -> navController.navigate(Routes.userProfile(u)) },
            )
        }
        composable(
            route = Routes.FOLLOWING,
            arguments = listOf(navArgument("username") { type = NavType.StringType }),
        ) { entry ->
            val username = entry.arguments?.getString("username").orEmpty()
            com.centrychat.android.feature.profile.FollowersScreen(
                username = username,
                isFollowers = false,
                onBack = { navController.popBackStack() },
                onUserClick = { u -> navController.navigate(Routes.userProfile(u)) },
            )
        }

        // ── Admin routes REMOVED (Round 3) ───────────────────────────────
        // The user explicitly requested that the Android app contains NO
        // admin UI — even admin users logging in to Android see only the
        // regular app UI. The backend's /api/v1/admin/* endpoints are NOT
        // removed; they remain available for the website admin dashboard
        // (which is the sole consumer).

        // ── Topics ───────────────────────────────────────────────────
        composable(Routes.TOPICS) {
            TopicsScreen(
                onTopicClick = { slug -> navController.navigate(Routes.topicDetail(slug)) },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.TOPIC_DETAIL,
            arguments = listOf(navArgument("slug") { type = NavType.StringType }),
        ) {
            // Reuse the FeedScreen with the topic's content (the backend's
            // /topics/{slug}/content returns the same shape as /feed/unified).
            // For brevity, the topic detail screen delegates to a placeholder
            // here — full implementation in the next iteration.
            com.centrychat.android.feature.topics.TopicDetailScreenPlaceholder(
                onBack = { navController.popBackStack() },
            )
        }

        // ── Collections ──────────────────────────────────────────────
        composable(Routes.COLLECTIONS) {
            CollectionsScreen(
                onCollectionClick = { id -> navController.navigate(Routes.collectionDetail(id)) },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.COLLECTION_DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
        ) {
            com.centrychat.android.feature.collections.CollectionDetailScreenPlaceholder(
                onBack = { navController.popBackStack() },
            )
        }

        // ── Playlists ────────────────────────────────────────────────
        composable(Routes.PLAYLISTS) {
            PlaylistsScreen(
                onPlaylistClick = { id -> navController.navigate(Routes.playlistDetail(id)) },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = Routes.PLAYLIST_DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.StringType }),
        ) { entry ->
            val playlistId = entry.arguments?.getString("id").orEmpty()
            com.centrychat.android.feature.playlists.PlaylistDetailScreen(
                playlistId = playlistId,
                onArticleClick = { id -> navController.navigate(Routes.articleDetail(id)) },
                onBack = { navController.popBackStack() },
            )
        }

        // ── Post composer ────────────────────────────────────────────
        composable(Routes.POST_COMPOSER) {
            PostComposerScreen(
                onPublished = { navController.popBackStack() },
                onBack = { navController.popBackStack() },
            )
        }

        // ── Article editor ───────────────────────────────────────────
        composable(Routes.ARTICLE_EDITOR) {
            com.centrychat.android.feature.post_composer.ArticleEditorScreenPlaceholder(
                onBack = { navController.popBackStack() },
            )
        }

        // ── Messaging ────────────────────────────────────────────────
        composable(Routes.CONVERSATIONS) {
            MainScaffold(navController = navController, currentRoute = currentRoute, appContainer = appContainer) { padding ->
                ConversationsScreen(
                    onConversationClick = { conversationId, otherUsername ->
                        navController.navigate(Routes.conversationDetail(conversationId, otherUsername))
                    },
                    onBack = { navController.popBackStack() },
                )
            }
        }
        composable(
            route = Routes.CONVERSATION_DETAIL,
            arguments = listOf(
                navArgument("conversationId") { type = NavType.StringType },
                navArgument("username") { type = NavType.StringType },
            ),
        ) { entry ->
            val conversationId = entry.arguments?.getString("conversationId").orEmpty()
            val otherUsername = entry.arguments?.getString("username").orEmpty()
            ConversationDetailScreen(
                conversationId = conversationId,
                otherUsername = otherUsername,
                onBack = { navController.popBackStack() },
            )
        }

        // ── Public site pages (about / privacy / terms) ─────────────
        composable(
            route = Routes.SITE_PAGE,
            arguments = listOf(navArgument("slug") { type = NavType.StringType }),
        ) { entry ->
            val slug = entry.arguments?.getString("slug").orEmpty()
            com.centrychat.android.feature.site_page.SitePageScreen(
                slug = slug,
                onBack = { navController.popBackStack() },
            )
        }
    }
}

@Composable
private fun MainScaffold(
    navController: NavHostController,
    currentRoute: String?,
    appContainer: AppContainer,
    content: @Composable (PaddingValues) -> Unit,
) {
    // Round 3: the bottom-nav no longer has any adminOnly destinations
    // (the ADMIN entry was removed in this round). All 5 remaining
    // destinations (Home, Search, Notifications, Profile, Messages) are
    // visible to every signed-in user, regardless of role. Admin users
    // logging in to Android see the SAME UI as regular users — no admin
    // dashboard, no admin-only buttons, no admin-only routes.
    val currentUser by appContainer.authRepository.currentUser.collectAsState()
    // Kept for backward-compat with any caller that reads `currentUser`
    // here; `Roles.canAccessAdmin` is no longer used for filtering.
    @Suppress("UNUSED_VARIABLE") val isAdmin = Roles.canAccessAdmin(currentUser)

    Scaffold(
        bottomBar = {
            val dest = BottomNavDestination.entries.firstOrNull { it.route == currentRoute }
            if (dest != null) {
                // Mirrors the website's mobile bottom-nav:
                //   h-14 (56dp), fixed bottom-0 z-30, bg-background/95 backdrop-blur
                //   border-t border-border, icon ~20dp + text-[11px] label.
                NavigationBar(
                    modifier = Modifier.height(56.dp),
                    containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background.copy(alpha = 0.95f),
                    tonalElevation = 0.dp,
                    windowInsets = WindowInsets(0),
                ) {
                    BottomNavDestination.entries
                        .forEach { item ->
                            NavigationBarItem(
                                selected = currentRoute == item.route,
                                onClick = {
                                    if (currentRoute != item.route) {
                                        navController.navigate(item.route) {
                                            popUpTo(Routes.HOME) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (currentRoute == item.route) item.selectedIcon else item.icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(22.dp),
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = androidx.compose.material3.MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 11.sp,
                                        ),
                                    )
                                },
                                colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                                    selectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                                    selectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                                    indicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                ),
                            )
                        }
                }
            }
        },
    ) { padding ->
        content(padding)
    }
}
