package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Mirrors `ResolvedMedia` in `src/lib/media/types.ts` (the website's
 * SINGLE media-resolution contract).
 *
 * Returned by `POST /api/v1/media/resolve` inside `ApiResponse.data.media`.
 *
 * Field semantics (verbatim from the website source — DO NOT rename):
 *  - [originalUrl]   — the original URL the user pasted.
 *  - [provider]      — "direct" | "google" | "pinterest" | "instagram" |
 *                      "tiktok" | "youtube" | "vimeo" | "facebook" | "x" |
 *                      "reddit" | "webpage" | "unknown".
 *  - [type]          — "image" | "video" | "embed" | "preview" | "unknown".
 *                      THE field the renderer dispatches on.
 *  - [mediaUrl]      — for type=="video" → the direct video file URL.
 *                      for type=="embed"  → the platform embed URL (iframe src).
 *                      for type=="image"  → the direct image URL.
 *                      for type=="preview"→ the thumbnail URL (if any).
 *                      for type=="unknown"→ empty string.
 *  - [embedUrl]     — for embeds, the iframe `src` URL (same as mediaUrl
 *                     when type=="embed"). Null otherwise.
 *  - [thumbnailUrl] — video poster / preview thumbnail.
 *  - [title]/[description] — page title + og:description (for preview cards).
 *  - [contentType]  — the server's actual Content-Type for mediaUrl
 *                     (only set when the resolver did an HTTP probe).
 *  - [probed]        — true if the resolver did a server-side HTTP probe.
 *  - [note]          — optional human-readable note (e.g. "resolver-error").
 *
 * IMPORTANT: this is the SINGLE source of truth on Android for "what kind
 * of media is this URL". Never re-parse URLs in the UI — always go through
 * the resolver.
 */
@Serializable
data class ResolvedMediaDto(
    @SerialName("originalUrl") val originalUrl: String = "",
    @SerialName("provider") val provider: String = "unknown",
    /** "image" | "video" | "embed" | "preview" | "unknown" — see [MediaType]. */
    @SerialName("type") val type: String = "unknown",
    @SerialName("mediaUrl") val mediaUrl: String = "",
    @SerialName("embedUrl") val embedUrl: String? = null,
    @SerialName("thumbnailUrl") val thumbnailUrl: String? = null,
    @SerialName("title") val title: String? = null,
    @SerialName("description") val description: String? = null,
    @SerialName("contentType") val contentType: String? = null,
    @SerialName("probed") val probed: Boolean = false,
    @SerialName("note") val note: String? = null,
)

/**
 * Request body for `POST /api/v1/media/resolve`.
 *
 * The website's resolver endpoint (`src/app/api/v1/media/resolve/route.ts`)
 * expects `{ "url": "..." }` and rejects requests without a non-empty `url`
 * field with HTTP 400 "Missing `url` field".
 */
@Serializable
data class MediaResolveRequest(
    val url: String,
)

/**
 * Response payload for `POST /api/v1/media/resolve`.
 *
 * The backend wraps the resolved media under a `media` key:
 *   `{ "ok": true, "data": { "media": { ... } } }`
 *
 * On resolver failure (SSRF, network error, etc.) the backend still returns
 * HTTP 200 with `media.type = "unknown"` + `media.provider = "unknown"` +
 * `media.note = "resolver-error"` — the call does NOT throw. So callers
 * can safely unwrap `.media` and dispatch by `type`.
 */
@Serializable
data class MediaResolveResponse(
    val media: ResolvedMediaDto,
)
