package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Messaging DTOs — mirror the shapes returned by `/api/v1/conversations`
 * and `/api/v1/conversations/{id}/messages`.
 *
 * The web app's `lib/messaging.ts` returns these exact shapes — the
 * Android client deserializes them as-is.
 *
 * REAL-TIME NOTE: the web uses socket.io for real-time (typing indicators,
 * presence, message arrival). The Android app uses a polling fallback
 * every 15s — same as the web's MainNav unread-count badge fallback.
 * Real-time socket.io integration is tracked as a follow-up.
 */

@Serializable
data class ConversationsListResponse(
    val conversations: List<ConversationDto> = emptyList(),
)

@Serializable
data class ConversationCreateResponse(
    val conversation: ConversationDto? = null,
)

/**
 * Conversation row in `GET /api/v1/conversations`.
 *
 * Mirrors `ConversationListItem` in `src/lib/messaging.ts`. The backend
 * returns these exact fields (NOT a full ConversationDto):
 *   {
 *     id, type, title,
 *     otherUser: { id, fullName, username, avatarColor, avatarUrl,
 *                  isVerified, status, lastSeenAt } | null,
 *     lastMessage: { id, content, senderId, createdAt, deletedAt } | null,
 *     unreadCount, updatedAt
 *   }
 *
 * IMPORTANT:
 *  - The `lastMessage` field has a SMALLER shape than [MessageDto] — it
 *    does NOT include `conversationId`, `sender`, `readAt`, `isEdited`,
 *    `isDeleted`. Using the full [MessageDto] here caused
 *    `SerializationException: Field 'conversationId' is required for type
 *    with serial name 'com.centrychat.android.data.model.MessageDto', but
 *    it was missing at path: S.data.conversations[0].lastMessage`.
 *    We now use [ConversationLastMessageDto], which exactly matches the
 *    backend's lastMessage shape. This is the proper fix — we did NOT
 *    make `conversationId` nullable on [MessageDto] to hide the bug.
 *  - The `otherUser` field is renamed to `participant` via @SerialName so
 *    the existing UI code that reads `conv.participant` keeps working.
 */
@Serializable
data class ConversationDto(
    val id: String,
    val type: String = "DIRECT",
    val title: String? = null,
    @SerialName("lastMessage") val lastMessage: ConversationLastMessageDto? = null,
    @SerialName("unreadCount") val unreadCount: Long = 0,
    @SerialName("lastReadAt") val lastReadAt: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
    // The "other participant" for direct conversations — used to render
    // the avatar + name in the conversation list. The backend names this
    // field `otherUser`; we keep the Kotlin name `participant` for
    // backward-compat with the existing UI.
    @SerialName("otherUser") val participant: UserProfileSummary? = null,
    val participants: List<UserProfileSummary> = emptyList(),
)

/**
 * The last message preview embedded in a conversation row.
 *
 * This is a SUBSET of [MessageDto] — the backend's `listConversations`
 * only sends these five fields in the `lastMessage` slot. It does NOT
 * include `conversationId` (the parent conversation already has `id`),
 * `sender`, `readAt`, `isEdited`, `isDeleted`, `mine`, `senderName`.
 */
@Serializable
data class ConversationLastMessageDto(
    val id: String,
    val content: String,
    @SerialName("senderId") val senderId: String,
    @SerialName("createdAt") val createdAt: String,
    @SerialName("deletedAt") val deletedAt: String? = null,
)

@Serializable
data class MessagesListResponse(
    val messages: List<MessageDto> = emptyList(),
)

/**
 * Single message returned by `GET /api/v1/conversations/{id}/messages`
 * (list) and `POST /api/v1/conversations/{id}/messages` (send).
 *
 * Mirrors `MessageDTO` in `src/lib/messaging.ts`. The backend's shape is:
 *   {
 *     id, conversationId, senderId, senderName,
 *     content, createdAt, readAt, editedAt, deletedAt, mine
 *   }
 *
 * The previous version of this DTO used `isEdited` / `isDeleted` boolean
 * fields and omitted `senderName` / `mine`. The backend NEVER sent
 * `isEdited` / `isDeleted` — it sent `editedAt` / `deletedAt` (nullable
 * ISO strings). With `coerceInputValues = true` the deserializer silently
 * defaulted `isEdited` / `isDeleted` to `false`, so the UI never showed
 * the "edited" tag or the "[message deleted]" placeholder. This is a
 * DATA BUG (the field was always wrong), not a crash bug.
 *
 * We now mirror the backend exactly: `editedAt` / `deletedAt` nullable
 * strings + `senderName` + `mine`. The legacy `isEdited` / `isDeleted`
 * boolean properties are exposed as computed properties so existing UI
 * code (e.g. `MessageBubble`) keeps compiling — they now return the
 * CORRECT value derived from the backend's `editedAt` / `deletedAt`.
 *
 * The `sender: UserProfileSummary?` field is kept (still defaults to
 * null) because some code paths check it — but the backend does NOT
 * populate it; use `senderName` + `mine` instead.
 */
@Serializable
data class MessageDto(
    val id: String,
    val content: String,
    @SerialName("conversationId") val conversationId: String,
    @SerialName("senderId") val senderId: String,
    @SerialName("senderName") val senderName: String? = null,
    val sender: UserProfileSummary? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
    @SerialName("editedAt") val editedAt: String? = null,
    @SerialName("deletedAt") val deletedAt: String? = null,
    @SerialName("readAt") val readAt: String? = null,
    val mine: Boolean = false,
) {
    /** True when the backend reports this message has been edited. */
    val isEdited: Boolean get() = editedAt != null

    /** True when the backend reports this message has been deleted. */
    val isDeleted: Boolean get() = deletedAt != null
}

/**
 * Response envelope for `POST /api/v1/conversations/{id}/messages`.
 *
 * The backend wraps the newly-created message under a `message` field:
 *   `{ "ok": true, "data": { "message": { ...MessageDTO... } } }`
 *
 * Previously the Retrofit interface declared `sendMessage` as returning
 * `ApiResponse<MessageDto>` directly, which made kotlinx-serialization
 * look for `id`, `content`, `conversationId` at the top level of
 * `data` and crash. This envelope matches the actual backend response.
 */
@Serializable
data class MessageEnvelope(
    val message: MessageDto,
)
