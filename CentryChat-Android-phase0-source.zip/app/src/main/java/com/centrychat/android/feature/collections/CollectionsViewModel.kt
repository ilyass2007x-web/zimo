package com.centrychat.android.feature.collections

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.CollectionDto
import com.centrychat.android.data.repository.CollectionsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CollectionsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: CollectionsRepository = appContainer.collectionsRepository

    private val _state = MutableStateFlow<UiState<List<CollectionDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<CollectionDto>>> = _state.asStateFlow()

    private val _createError = MutableStateFlow<String?>(null)
    val createError: StateFlow<String?> = _createError.asStateFlow()

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val list = repo.getCollections().collections
                _state.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load collections.")
            }
        }
    }

    fun create(name: String, description: String?) {
        viewModelScope.launch {
            try {
                repo.createCollection(name = name, description = description)
                _createError.value = null
                load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _createError.value = e.message ?: "Could not create collection."
            }
        }
    }

    fun delete(id: String) {
        viewModelScope.launch {
            try { repo.deleteCollection(id); load() } catch (_: Exception) {}
        }
    }
}
