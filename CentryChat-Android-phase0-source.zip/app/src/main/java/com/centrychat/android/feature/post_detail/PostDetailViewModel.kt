package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.repository.PostsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * The post-detail + comments ViewModel.
 *
 * Loads a single post + its comments in parallel. Supports:
 *  - Posting a new top-level comment
 *  - Posting a reply (with a parentCommentId)
 *  - Toggling like on a comment
 */
class PostDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PostsRepository = appContainer.postsRepository

    private val _postState = MutableStateFlow<UiState<PostDto>>(UiState.Loading)
    val postState: StateFlow<UiState<PostDto>> = _postState.asStateFlow()

    private val _commentsState = MutableStateFlow<UiState<List<CommentDto>>>(UiState.Loading)
    val commentsState: StateFlow<UiState<List<CommentDto>>> = _commentsState.asStateFlow()

    private val _isSendingComment = MutableStateFlow(false)
    val isSendingComment: StateFlow<Boolean> = _isSendingComment.asStateFlow()

    private val _replyTarget = MutableStateFlow<CommentDto?>(null)
    val replyTarget: StateFlow<CommentDto?> = _replyTarget.asStateFlow()

    fun loadPost(postId: String) {
        _postState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val post = repo.getPost(postId)
                _postState.value = UiState.Success(post)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _postState.value = UiState.Error(e.message ?: "Could not load post.")
            }
        }
    }

    fun loadComments(postId: String) {
        _commentsState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = repo.getComments(postId = postId, limit = 100)
                _commentsState.value = if (response.comments.isEmpty()) {
                    UiState.Empty
                } else {
                    UiState.Success(response.comments)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _commentsState.value = UiState.Error(e.message ?: "Could not load comments.")
            }
        }
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleLike(postId)
                val current = (_postState.value as? UiState.Success)?.data ?: return@launch
                _postState.value = UiState.Success(
                    current.copy(isLiked = result.liked, likeCount = result.likeCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — don't surface like errors
            }
        }
    }

    /**
     * Record a SHARE interaction on the post. Calls the backend's
     * `POST /api/v1/posts/{id}/share` endpoint (type="SHARE") and
     * reconciles the post's shareCount with the server-authoritative
     * total returned by the backend.
     *
     * The caller (the screen) is responsible for invoking the Android
     * system share sheet BEFORE calling this — the backend records the
     * event only when the share was actually performed (mirrors the
     * web's behavior in `src/components/posts/share-dialog.tsx`).
     */
    fun sharePost(postId: String) {
        viewModelScope.launch {
            try {
                val result = repo.sharePost(postId, type = "SHARE")
                val current = (_postState.value as? UiState.Success)?.data ?: return@launch
                _postState.value = UiState.Success(
                    current.copy(shareCount = result.shareCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — don't surface share-tracking errors
                // (the user successfully shared; we just couldn't record
                // the event — same behavior as the web).
            }
        }
    }

    fun toggleCommentLike(commentId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleCommentLike(commentId)
                val current = (_commentsState.value as? UiState.Success)?.data ?: return@launch
                val updated = current.map { c ->
                    if (c.id == commentId) {
                        c.copy(isLiked = result.liked, likeCount = result.likeCount)
                    } else c
                }
                _commentsState.value = UiState.Success(updated)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun sendComment(postId: String, content: String, parentCommentId: String? = null) {
        if (content.isBlank() || _isSendingComment.value) return
        viewModelScope.launch {
            _isSendingComment.value = true
            try {
                val newComment = repo.createComment(
                    postId = postId,
                    content = content,
                    parentCommentId = parentCommentId,
                )
                val current = (_commentsState.value as? UiState.Success)?.data
                if (current != null) {
                    if (parentCommentId != null) {
                        // Insert as a reply to the parent comment.
                        val updated = current.map { c ->
                            if (c.id == parentCommentId) {
                                c.copy(replies = c.replies + newComment)
                            } else c
                        }
                        _commentsState.value = UiState.Success(updated)
                    } else {
                        // Insert as a new top-level comment.
                        _commentsState.value = UiState.Success(listOf(newComment) + current)
                    }
                }
                _replyTarget.value = null
                // Update the post's comment count
                val post = (_postState.value as? UiState.Success)?.data
                if (post != null) {
                    _postState.value = UiState.Success(post.copy(commentCount = post.commentCount + 1))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — the user can retry
            } finally {
                _isSendingComment.value = false
            }
        }
    }

    fun setReplyTarget(comment: CommentDto?) {
        _replyTarget.value = comment
    }
}
