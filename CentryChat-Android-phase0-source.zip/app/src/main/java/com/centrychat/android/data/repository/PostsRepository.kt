package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.PagedPostsResponse
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.PostEnvelope
import com.centrychat.android.data.model.ShareResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Posts repository.
 *
 * Wraps the posts + post-comments + post-likes endpoints. The Origin header
 * is passed on every state-changing call to satisfy the backend's CSRF check.
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses (e.g. "Post not
 * found." on a 404). Without this, the ViewModel would display a generic
 * "HTTP 404 ..." string from Retrofit's default HttpException message.
 */
class PostsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of posts (optionally filtered by author). */
    suspend fun getPosts(
        cursor: String? = null,
        limit: Int = 20,
        authorId: String? = null,
    ): PagedPostsResponse {
        return safeApiCall {
            api.getPosts(
                limit = limit,
                cursor = cursor,
                authorId = authorId,
            )
        }
    }

    /** Fetch a single post by ID.
     *
     *  The backend wraps the post under `data.post` (NOT directly under
     *  `data`), so the API interface returns [PostEnvelope] and we
     *  extract `.post` here. Without this unwrap the previous code crashed
     *  with `SerializationException: Fields [id, content, createdAt,
     *  author] are required for type PostDto, but they were missing at
     *  path: S.data`. */
    suspend fun getPost(id: String): PostDto {
        return safeApiCall { api.getPost(id) }.post
    }

    /** Create a new text post.
     *
     *  The backend wraps the newly-created post under `data.post`, so
     *  we unwrap via [PostEnvelope.post]. See [getPost] for the rationale. */
    suspend fun createPost(content: String): PostDto {
        val envelope: PostEnvelope = safeApiCall {
            api.createPost(
                body = mapOf("content" to content),
                origin = origin,
            )
        }
        return envelope.post
    }

    /** Delete a post owned by the current user. */
    suspend fun deletePost(id: String): Boolean {
        safeApiCall { api.deletePost(id = id, origin = origin) }
        return true
    }

    /** Toggle like on a post. Returns (liked, likeCount). */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return safeApiCall { api.togglePostLike(id = id, origin = origin) }
    }

    /**
     * Record a SHARE interaction on a post. Mirrors the web's ShareDialog
     * behavior (records one event per successful share / link-copy).
     *
     * Backend: `POST /api/v1/posts/{id}/share` (see
     * src/app/api/v1/posts/[id]/share/route.ts). Records a PostInteraction
     * row + increments the post's shareCount. Returns the
     * server-authoritative shareCount so the client can reconcile its
     * optimistic UI update.
     *
     * @param type "SHARE" (native share — counts toward public shareCount)
     *             OR "LINK_COPY" (link copy — tracked separately, does
     *             NOT count toward the public shareCount).
     */
    suspend fun sharePost(id: String, type: String = "SHARE"): ShareResponse {
        val body = mapOf<String, String?>("type" to type)
        return safeApiCall { api.sharePost(id = id, body = body, origin = origin) }
    }

    /** Fetch paginated comments for a post (sorted by newest by default). */
    suspend fun getComments(
        postId: String,
        cursor: String? = null,
        limit: Int = 50,
        sort: String = "newest",
    ): CommentsResponse {
        return safeApiCall {
            api.getPostComments(
                id = postId,
                limit = limit,
                cursor = cursor,
                sort = sort,
            )
        }
    }

    /** Create a top-level comment or a reply (when parentCommentId is set). */
    suspend fun createComment(
        postId: String,
        content: String,
        parentCommentId: String? = null,
    ): CommentDto {
        val body = buildMap {
            put("content", content)
            if (parentCommentId != null) put("parentCommentId", parentCommentId)
        }
        return safeApiCall {
            api.createPostComment(
                id = postId,
                body = body,
                origin = origin,
            )
        }
    }

    /** Toggle like on a comment. */
    suspend fun toggleCommentLike(commentId: String): ToggleLikeResponse {
        return safeApiCall { api.toggleCommentLike(id = commentId, origin = origin) }
    }
}
