package com.centrychat.android

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.centrychat.android.core.AppContainer
import com.centrychat.android.feature.articles.ArticlesViewModel
import com.centrychat.android.feature.auth.AuthViewModel
import com.centrychat.android.feature.feed.FeedViewModel
import com.centrychat.android.feature.notifications.NotificationsViewModel
import com.centrychat.android.feature.post_detail.PostDetailViewModel
import com.centrychat.android.feature.profile.ProfileViewModel
import com.centrychat.android.feature.search.SearchViewModel
import com.centrychat.android.feature.settings.SettingsViewModel

/**
 * Convenience entry points used by the Compose UI to obtain ViewModels that
 * are wired up to the [AppContainer] (Retrofit + repositories + session store).
 *
 * Each `rememberXViewModel()` is a thin wrapper around `viewModel()` that
 * supplies a [ViewModelProvider.Factory] bound to the application's container.
 * The pattern keeps Compose code free of factory boilerplate + ensures all
 * ViewModels share the same singletons.
 */

private fun appContainer(application: Application): AppContainer =
    (application as CentryChatApp).appContainer

@Composable
fun rememberAuthViewModel(): AuthViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AuthViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberFeedViewModel(): FeedViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                FeedViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberArticlesViewModel(): ArticlesViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                ArticlesViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberPostDetailViewModel(): PostDetailViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                PostDetailViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberProfileViewModel(): ProfileViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                ProfileViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberNotificationsViewModel(): NotificationsViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                NotificationsViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberSearchViewModel(): SearchViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                SearchViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberSettingsViewModel(): SettingsViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                SettingsViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

// ── Phase 0 stabilization: removed `rememberAdminViewModel` ─────────────
// The admin UI was removed from Android in Round 3 per spec — admin users
// see the same UI as regular users. The `rememberAdminViewModel` factory
// was the ONLY caller of `AdminViewModel` + `AdminRepository` + 24 admin
// API endpoints declared in `CentryChatApi`. With the factory removed,
// dead-code elimination (Kotlin compiler + R8 in release builds) can
// strip the entire admin code path.
//
// If admin UI is wanted in the future, re-add this factory + the
// `AdminDashboardScreen` / `AdminSectionScreen` screens + wire a
// `Routes.ADMIN_DASHBOARD` route in `CentryChatRoot.kt`.

@Composable
fun rememberTopicsViewModel(): com.centrychat.android.feature.topics.TopicsViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                com.centrychat.android.feature.topics.TopicsViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberCollectionsViewModel(): com.centrychat.android.feature.collections.CollectionsViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                com.centrychat.android.feature.collections.CollectionsViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberPlaylistsViewModel(): com.centrychat.android.feature.playlists.PlaylistsViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                com.centrychat.android.feature.playlists.PlaylistsViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}

@Composable
fun rememberPostComposerViewModel(): com.centrychat.android.feature.post_composer.PostComposerViewModel {
    val context = LocalContext.current
    val factory = remember(context) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                com.centrychat.android.feature.post_composer.PostComposerViewModel(appContainer(context.applicationContext as Application)) as T
        }
    }
    return viewModel(factory = factory)
}
