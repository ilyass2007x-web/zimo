# CentryChat Android

A native Android client for the **CentryChat** social platform. Built with
Kotlin + Jetpack Compose + Material 3, sharing the **same backend** as the
existing Next.js web app — no separate backend, no separate database, no
separate authentication system.

```
            CentryChat Backend (Next.js + Neon + Prisma + Resend)
                       │
              ┌────────┴────────┐
              │                 │
          Web (Next.js)    Android (this app)
              │                 │
              └─────────────────┘
                        │
                  Same Database
                  Same Accounts
                  Same Backend
```

## 1. Requirements

- **Android Studio Ladybug (2024.2.1) or newer** — recommended.
- **JDK 17** — Android Studio bundles this; if you build from the CLI, install
  Temurin 17 or Oracle JDK 17.
- **Android SDK 35** — Android Studio will prompt to install it on first open.
- **Gradle 8.9** — provided by the included `gradle-wrapper.jar` (no separate
  install needed).
- **Kotlin 2.0.21** — pulled in by the Gradle plugin, no manual install.

## 2. Opening the project

1. Unzip `CentryChat-Android-Final.zip` to any folder.
2. Open Android Studio → `File → Open…` → select the unzipped folder.
3. Android Studio will:
   - Download the Android SDK Platform 35 + Build-Tools 35 if not present
     (just click "Install" on the prompt).
   - Run `./gradlew` to set up the Gradle wrapper.
   - Sync the project + download all dependencies from `google()` and
     `mavenCentral()`.
4. After sync completes, click the **Run** ▶ button to launch the app on an
   emulator or a connected device.

## 3. API configuration

The app talks to the CentryChat backend over HTTPS. The base URL is configured
in `app/build.gradle.kts`:

```kotlin
buildConfigField("String", "API_BASE_URL", "\"https://sentrychat.netlify.app\"")
buildConfigField("String", "API_ORIGIN",   "\"https://sentrychat.netlify.app\"")
```

### How to change the backend URL

There are three ways, in order of cleanliness:

1. **Recommended — for staging builds:** edit the `buildConfigField` line in
   the `debug { … }` block:
   ```kotlin
   buildConfigField("String", "API_BASE_URL", "\"https://staging.example.com\"")
   buildConfigField("String", "API_ORIGIN",   "\"https://staging.example.com\"")
   ```
2. **Via a Gradle property** (for local dev without touching the build file):
   add this line to `~/.gradle/gradle.properties`:
   ```
   centrychat.apiBaseUrl=https://staging.example.com
   ```
   The `debug` build type picks this up automatically.
3. **For release builds:** always uses the hardcoded production URL — never
   override it from outside.

> **Why is `API_ORIGIN` a separate field?** The backend's CSRF protection
> compares the request's `Origin` header against the deployment URL. The
> Android app explicitly sends `Origin: <API_ORIGIN>` on every POST/PUT/
> PATCH/DELETE so the backend accepts the request (browser requests include
> this automatically, but OkHttp does not).

## 4. Authentication flow

The Android app **reuses the web app's authentication system** — no separate
user database. Concretely:

- **Same cookies:** the backend's iron-session cookie (`messenger_session`) is
  captured by OkHttp's `PersistentCookieJar` and stored in **encrypted
  SharedPreferences** (AES-GCM 256-bit at rest).
- **Same `/api/v1/auth/login`** endpoint — the app POSTs `{email, password}`
  + the `Origin` header.
- **Same 7-day session TTL** — when the cookie expires, the backend returns
  HTTP 401 and the `UnauthorizedInterceptor` clears the local session + the
  UI redirects to the login screen.
- **Same logout flow** — the app calls `/api/v1/auth/logout` (best-effort;
  non-fatal if it fails) and clears the local cookie.

## 5. Forgot-password + Resend integration

The app uses the **exact same password-reset flow** as the web app:

```
Android
  │
  │  POST /api/v1/auth/forgot-password  { email }
  ▼
Next.js Backend
  │
  │  (issuePasswordResetToken → single-use, 30-min-expiring token)
  ▼
Resend (server-side, using RESEND_API_KEY env var — NEVER shipped to Android)
  │
  ▼
User's email inbox
  │
  │  (user taps the reset link → opens the Android app via deep-link)
  ▼
Android Reset Password screen
  │
  │  POST /api/v1/auth/reset-password  { token, password, confirmPassword }
  ▼
Backend → user.passwordHash updated → all sessions revoked
```

**The Resend API key is NEVER in the APK** — it lives only in the backend's
Netlify environment variables.

## 6. Backend changes

**No backend changes are required.** The app talks to the existing
`/api/v1/*` endpoints — no new routes, no new database schema, no new env
vars.

The only "integration" the backend requires is to accept requests with the
`Origin: https://centrychat.netlify.app` header on state-changing endpoints
(this is already the case — the CSRF check in `src/lib/security/csrf.ts`
compares Origin against `NEXT_PUBLIC_APP_BASE_URL` + the request's own
origin, both of which match the production URL).

## 7. Environment variables

**The Android app does NOT need any environment variables.** All secrets
(`DATABASE_URL`, `AUTH_SECRET`, `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, etc.)
remain on the backend (Netlify). The APK only contains:

- `API_BASE_URL` — the public HTTPS URL of the deployed CentryChat site.
- `API_ORIGIN` — same value, used for the CSRF Origin header.

Both are baked into `BuildConfig` at build time, NOT loaded from a `.env`
file.

## 8. Architecture

```
app/
├── core/                      # App-wide singletons + infrastructure
│   ├── AppContainer.kt        # Manual DI container (Retrofit + repos)
│   ├── LocalAppContainer.kt   # CompositionLocal for Compose access
│   ├── network/                # OkHttp + Retrofit + interceptors + cookie jar
│   ├── storage/                # Encrypted SharedPreferences + session events
│   ├── theme/                  # Material 3 colors + typography
│   └── util/                   # UiState, PaginatedState, TimeFormatter, TextUtils
├── data/
│   ├── model/                  # Kotlinx-serialization DTOs (mirror backend types)
│   └── repository/             # Repository layer (wraps Retrofit)
├── feature/                    # One package per feature screen
│   ├── auth/                   # Login, Register, ForgotPassword, ResetPassword
│   ├── feed/                   # Home unified feed (posts + articles)
│   ├── articles/               # Articles list
│   ├── post_detail/            # Post detail + comments + article detail
│   ├── profile/               # Profile + EditProfile + Followers/Following
│   ├── notifications/         # Activity feed
│   ├── search/                 # Search all (users/posts/articles)
│   ├── settings/               # App settings (dark mode, language, logout)
│   └── splash/                 # Cold-start session check
├── navigation/                 # NavHost + routes + bottom-nav destinations
├── ui/components/              # Shared Composables (Avatar, VerifiedBadge, etc.)
├── CentryChatApp.kt            # Application class (initializes AppContainer)
├── MainActivity.kt             # Single launcher activity (mounts Compose)
└── AppViewModels.kt            # Compose-side helpers to obtain ViewModels
```

The architecture follows **MVVM + Repository** with **manual DI** (no Hilt or
Koin — the project is small enough that a 200-line DI framework would be
overkill). Each screen:

1. Obtains a ViewModel via a `remember{}`-backed factory (see
   `AppViewModels.kt`).
2. Observes a `StateFlow<UiState<T>>` with `collectAsStateWithLifecycle()`.
3. Renders a sealed-state-aware UI (Loading / Success / Empty / Error) so the
   compiler enforces handling every state.

## 9. Performance + UX features

- **Cursor-based pagination** on every list (feed, articles, notifications,
  search results). No offset-based pagination → no skipped/duplicated items
  when new content is created mid-scroll.
- **Infinite scroll** via `LazyColumn` + a `derivedStateOf` predicate that
  fires `loadMore()` when the last visible item is within 3 of the end.
- **Pull-to-refresh** on the feed (via the `refresh` callback).
- **Image caching** via Coil (in-memory + disk cache, automatic eviction).
- **Encrypted session storage** (AES-GCM 256-bit) so the cookie survives a
  device reboot but not a backup extraction.
- **Edge-to-edge** layout with theme-aware status bar tinting.
- **Splash screen** via the Android 12 SplashScreen API + a theme swap to
  avoid the white flash before Compose mounts.
- **Debounced search** (350 ms) to avoid spamming the backend on every
  keystroke.
- **StateFlow + Lifecycle-aware collection** so the UI doesn't emit state
  when the screen is in the background.

## 10. Security

- **No secrets in the APK** — no `DATABASE_URL`, no `AUTH_SECRET`, no
  `RESEND_API_KEY`, no admin credentials. The APK contains only the public
  HTTPS URL of the deployed CentryChat site.
- **Encrypted session cookie storage** via AndroidX Security's
  `EncryptedSharedPreferences` (AES-GCM 256-bit, MasterKey tied to the
  Android keystore).
- **No password / token / cookie logging** — the OkHttp logging interceptor
  runs at `HEADERS` level in debug builds (which itself redacts `Cookie`,
  `Set-Cookie`, and `Authorization` headers) and is **completely disabled**
  in release builds (`NONE` level).
- **HTTPS-only** — `usesCleartextTraffic="false"` in the manifest +
  `<network-security-config>` denies HTTP traffic to all domains.
- **CSRF compliance** — every state-changing request carries an `Origin`
  header matching the deployment URL, satisfying the backend's CSRF check
  without weakening the SameSite=Lax cookie.
- **Automatic session revocation** — HTTP 401 responses trigger
  `UnauthorizedInterceptor` → clears the local session + emits a
  `SessionEvent.Expired` event → the UI pops back to the login screen.

## 11. Deep-linking architecture

The manifest declares an `<intent-filter>` for `https://centrychat.netlify.app`
links + a custom `centrychat://` scheme. This means future deep-link routes
(`centrychat.netlify.app/post/<id>`, `…/article/<id>`, `…/profile/<username>`)
can be routed into the app once App Links verification is configured on the
backend.

The current routing graph already supports the deep-link patterns — see
`navigation/Routes.kt` for the route templates.

## 12. Future iOS support

The API contract layer (`data/model/` + `data/repository/`) is intentionally
written to be platform-agnostic. The DTOs match the JSON shapes exactly, and
the repository method signatures don't depend on any Android-specific type.
This makes porting to iOS (Swift + URLSession) a straightforward translation
of the DTOs + repository method calls — the backend side requires zero
changes.

## 13. Build verification

The project was built successfully with:

- AGP 8.7.3
- Gradle 8.9
- Kotlin 2.0.21
- Compose BOM 2024.11.00
- compileSdk 35, minSdk 24, targetSdk 35
- JDK 17

Build command used:

```bash
./gradlew :app:assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk` (~19.7 MB).

## 14. License + ownership

This Android client is part of the CentryChat platform. All backend code,
brand assets, and the CentryChat name remain the property of the CentryChat
project.
